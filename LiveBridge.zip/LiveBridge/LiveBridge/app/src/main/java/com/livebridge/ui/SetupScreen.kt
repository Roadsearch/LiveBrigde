package com.livebridge.ui

import android.content.res.Configuration
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.dp
import com.livebridge.Prefs
import com.livebridge.rememberPref
import com.livebridge.rtmp.Quality
import com.livebridge.rtmp.RtmpUi
import com.livebridge.rtmp.StreamController
import com.livebridge.studio.SourceType
import com.livebridge.studio.StudioStore

val PLATFORMS = listOf("YouTube", "Twitch", "Facebook", "Autre")
private const val YOUTUBE_HELP = "YouTube Studio → Créer → Passer en direct → Diffusion → Clé de stream."

fun rtmpUrl(platform: String, ytTls: String, customBase: String, key: String): String {
    val base = when (platform) {
        "YouTube" -> if (ytTls == "1") "rtmps://a.rtmps.youtube.com:443/live2" else "rtmp://a.rtmp.youtube.com/live2"
        "Twitch" -> "rtmp://live.twitch.tv/app"
        "Facebook" -> "rtmps://live-api-s.facebook.com:443/rtmp"
        else -> customBase.trim()
    }
    return when {
        base.isBlank() -> ""
        key.isBlank() -> base
        else -> base.trimEnd('/') + "/" + key.trim().trimStart('/')
    }
}

@Composable
fun SetupScreen(
    controller: StreamController,
    store: StudioStore,
    prefs: Prefs,
    blockedByOther: Boolean,
    onStart: () -> Unit,
    onOpenElements: () -> Unit
) {
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val ui by controller.ui.collectAsState()
    val studio by store.state.collectAsState()
    val title = rememberPref(prefs, "stream_title", "Mon direct")
    val category = rememberPref(prefs, "stream_category", "Discussion & Voyage")
    val platform = rememberPref(prefs, "rtmp_platform", "YouTube")
    val ytTls = rememberPref(prefs, "rtmp_yt_tls", "1")
    val customBase = rememberPref(prefs, "rtmp_custom_base")
    val key = rememberPref(prefs, "rtmp_key")
    var showSettings by remember { mutableStateOf(false) }
    val url = rtmpUrl(platform.value, ytTls.value, customBase.value, key.value)
    val canStart = url.isNotBlank() && !blockedByOther && !ui.connecting && !ui.streaming
    val scene = studio.current

    if (landscape) {
        Row(
            Modifier.fillMaxSize().background(StudioBg).padding(10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Column(Modifier.weight(1.35f).fillMaxHeight()) {
                StudioTopBar(ui)
                Spacer(Modifier.height(8.dp))
                PreviewPanel(controller, store, scene, Modifier.weight(1f).fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                ScenesBar(store, onOpenElements)
            }
            Column(
                Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SourcesMixer(store, scene)
                StreamPanel(title, category, platform, ytTls, customBase, key)
                ControlPanel(controller, ui, onOpenElements)
                if (showSettings) AdvancedPanel(controller, ui)
                BottomStartButton(canStart, blockedByOther, ui, onStart)
                TextButton(onClick = { showSettings = !showSettings }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Filled.Settings, null, Modifier.size(17.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(if (showSettings) "Masquer les réglages" else "Réglages avancés")
                }
            }
        }
    } else {
        Column(Modifier.fillMaxSize().background(StudioBg)) {
            StudioTopBar(ui)
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 10.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PreviewPanel(controller, store, scene, Modifier.fillMaxWidth().height(230.dp))
                ScenesBar(store, onOpenElements)
                SourcesMixer(store, scene)
                StreamPanel(title, category, platform, ytTls, customBase, key)
                ControlPanel(controller, ui, onOpenElements)
                if (showSettings) AdvancedPanel(controller, ui)
                BottomStartButton(canStart, blockedByOther, ui, onStart)
                TextButton(onClick = { showSettings = !showSettings }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Filled.Settings, null, Modifier.size(17.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(if (showSettings) "Masquer les réglages" else "Réglages avancés")
                }
            }
        }
    }
}

private val StudioBg = Color(0xFF080B10)
private val StudioPanel = Color(0xFF11161E)
private val StudioPanel2 = Color(0xFF171E28)
private val StudioBorder = Color(0xFF293342)
private val StudioText = Color(0xFFE9EDF3)
private val StudioMuted = Color(0xFF8994A3)
private val StudioGreen = Color(0xFF35D07F)

@Composable
private fun StudioTopBar(ui: RtmpUi) {
    Row(
        Modifier.fillMaxWidth().height(52.dp).clip(RoundedCornerShape(12.dp)).background(StudioPanel).padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("LIVEBRIDGE", style = MaterialTheme.typography.titleMedium, color = StudioText)
        Spacer(Modifier.width(10.dp))
        Surface(shape = RoundedCornerShape(50), color = if (ui.streaming) LiveRed.copy(alpha = .18f) else StudioPanel2) {
            Row(Modifier.padding(horizontal = 9.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(7.dp).clip(RoundedCornerShape(50)).background(if (ui.streaming) LiveRed else StudioGreen))
                Spacer(Modifier.width(6.dp))
                Text(if (ui.streaming) "EN DIRECT" else "PRÊT", style = MaterialTheme.typography.labelSmall, color = StudioText)
            }
        }
        Spacer(Modifier.weight(1f))
        IconButton(onClick = {}) { Icon(Icons.Filled.MoreVert, "Menu", tint = StudioText) }
        IconButton(onClick = {}) { Icon(Icons.Filled.Settings, "Paramètres", tint = StudioText) }
    }
}

@Composable
private fun PreviewPanel(controller: StreamController, store: StudioStore, scene: com.livebridge.studio.Scene, modifier: Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color.Black), shape = RoundedCornerShape(12.dp)) {
        Box(Modifier.fillMaxSize()) {
            PreviewCanvas(controller, store, scene, editable = false, modifier = Modifier.fillMaxSize())
            Surface(Modifier.padding(9.dp), shape = RoundedCornerShape(6.dp), color = Color.Black.copy(alpha = .72f)) {
                Text("APERÇU  •  ${scene.name}", Modifier.padding(horizontal = 8.dp, vertical = 5.dp), style = MaterialTheme.typography.labelSmall, color = Color.White)
            }
        }
    }
}

@Composable
private fun ScenesBar(store: StudioStore, onOpenElements: () -> Unit) {
    val studio by store.state.collectAsState()
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(StudioPanel).padding(7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("SCÈNES", style = MaterialTheme.typography.labelMedium, color = StudioMuted, modifier = Modifier.padding(horizontal = 6.dp))
        Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            studio.scenes.forEach { scene ->
                Surface(shape = RoundedCornerShape(7.dp), color = if (scene.id == studio.current.id) MaterialTheme.colorScheme.primary.copy(alpha=.22f) else StudioPanel2) {
                    Text(scene.name, Modifier.padding(horizontal = 12.dp, vertical = 8.dp), color = StudioText, style = MaterialTheme.typography.labelMedium)
                }
            }
        }
        IconButton(onClick = onOpenElements) { Icon(Icons.Filled.Add, "Gérer les scènes", tint = StudioText) }
    }
}

@Composable
private fun SourcesMixer(store: StudioStore, scene: com.livebridge.studio.Scene) {
    val sources = scene.sources
    Card(colors = CardDefaults.cardColors(containerColor = StudioPanel), shape = RoundedCornerShape(10.dp)) {
        Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("SOURCES", style = MaterialTheme.typography.labelMedium, color = StudioMuted)
                Spacer(Modifier.weight(1f))
                Text("MIXEUR", style = MaterialTheme.typography.labelMedium, color = StudioMuted)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    sources.take(3).forEach { source ->
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(7.dp)).background(StudioPanel2).padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(if (source.type == SourceType.CAMERA) Icons.Filled.CameraAlt else Icons.Filled.Visibility, null, Modifier.size(16.dp), tint = StudioText)
                            Spacer(Modifier.width(7.dp))
                            Text(source.name, Modifier.weight(1f), style = MaterialTheme.typography.labelSmall, color = StudioText, maxLines = 1)
                            Box(Modifier.size(6.dp).clip(RoundedCornerShape(50)).background(StudioGreen))
                        }
                    }
                    if (sources.isEmpty()) Text("Aucune source", color = StudioMuted, style = MaterialTheme.typography.bodySmall)
                }
                Column(Modifier.weight(.9f), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    MixerLine(Icons.Filled.Mic, "Micro", 0.72f)
                    MixerLine(Icons.Filled.GraphicEq, "Système", 0.48f)
                }
            }
        }
    }
}

@Composable
private fun MixerLine(icon: androidx.compose.ui.graphics.vector.ImageVector, name: String, level: Float) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, Modifier.size(15.dp), tint = StudioMuted)
        Spacer(Modifier.width(5.dp))
        Text(name, style = MaterialTheme.typography.labelSmall, color = StudioMuted)
        Spacer(Modifier.width(5.dp))
        Box(Modifier.weight(1f).height(6.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xFF26303C))) {
            Box(Modifier.fillMaxWidth(level).fillMaxHeight().background(if (level > .65f) LiveRed else StudioGreen))
        }
    }
}

@Composable
private fun StreamPanel(title: androidx.compose.runtime.MutableState<String>, category: androidx.compose.runtime.MutableState<String>, platform: androidx.compose.runtime.MutableState<String>, ytTls: androidx.compose.runtime.MutableState<String>, customBase: androidx.compose.runtime.MutableState<String>, key: androidx.compose.runtime.MutableState<String>) {
    Card(colors = CardDefaults.cardColors(containerColor = StudioPanel), shape = RoundedCornerShape(10.dp)) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("DIFFUSION", style = MaterialTheme.typography.labelMedium, color = StudioMuted)
                Spacer(Modifier.weight(1f))
                Text(platform.value, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            }
            Field(title, "Titre du direct")
            Field(category, "Catégorie")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                PLATFORMS.forEach { name ->
                    Surface(onClick = { platform.value = name }, shape = RoundedCornerShape(7.dp), color = if (platform.value == name) MaterialTheme.colorScheme.primary.copy(alpha=.22f) else StudioPanel2) {
                        Text(name, Modifier.padding(horizontal = 11.dp, vertical = 7.dp), style = MaterialTheme.typography.labelSmall, color = StudioText)
                    }
                }
            }
            if (platform.value == "YouTube") {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Surface(onClick = { ytTls.value = "1" }, shape = RoundedCornerShape(6.dp), color = if (ytTls.value == "1") MaterialTheme.colorScheme.primary.copy(alpha=.2f) else StudioPanel2) { Text("RTMPS", Modifier.padding(8.dp), style = MaterialTheme.typography.labelSmall, color = StudioText) }
                    Surface(onClick = { ytTls.value = "0" }, shape = RoundedCornerShape(6.dp), color = if (ytTls.value != "1") MaterialTheme.colorScheme.primary.copy(alpha=.2f) else StudioPanel2) { Text("RTMP", Modifier.padding(8.dp), style = MaterialTheme.typography.labelSmall, color = StudioText) }
                }
                Text(YOUTUBE_HELP, style = MaterialTheme.typography.bodySmall, color = StudioMuted)
            }
            if (platform.value == "Autre") Field(customBase, "URL du serveur")
            Field(key, if (platform.value == "Autre") "Clé / nom du flux" else "Clé de stream", secret = true)
        }
    }
}

@Composable
private fun ControlPanel(controller: StreamController, ui: RtmpUi, onOpenElements: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = StudioPanel), shape = RoundedCornerShape(10.dp)) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text("CONTRÔLES", style = MaterialTheme.typography.labelMedium, color = StudioMuted)
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Micro", Modifier.weight(1f), color = StudioText, style = MaterialTheme.typography.bodySmall)
                Switch(checked = !ui.micMuted, onCheckedChange = { controller.setMicMuted(!it) })
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                OutlinedButton(onClick = { controller.switchCamera() }, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.CameraAlt, null, Modifier.size(17.dp)); Spacer(Modifier.width(5.dp)); Text("Caméra") }
                OutlinedButton(onClick = onOpenElements, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.Add, null, Modifier.size(17.dp)); Spacer(Modifier.width(5.dp)); Text("Sources") }
            }
        }
    }
}

@Composable
private fun AdvancedPanel(controller: StreamController, ui: RtmpUi) {
    val live = ui.streaming || ui.connecting || ui.recording
    Card(colors = CardDefaults.cardColors(containerColor = StudioPanel), shape = RoundedCornerShape(10.dp)) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text("QUALITÉ", style = MaterialTheme.typography.labelMedium, color = StudioMuted)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Quality.entries.forEach { q ->
                    Surface(onClick = { controller.setQuality(q) }, enabled = !live, shape = RoundedCornerShape(7.dp), color = if (ui.quality == q) MaterialTheme.colorScheme.primary.copy(alpha=.22f) else StudioPanel2) {
                        Text(q.label, Modifier.padding(horizontal = 10.dp, vertical = 7.dp), style = MaterialTheme.typography.labelSmall, color = StudioText)
                    }
                }
            }
        }
    }
}

@Composable
private fun BottomStartButton(canStart: Boolean, blockedByOther: Boolean, ui: RtmpUi, onStart: () -> Unit) {
    Button(
        onClick = onStart,
        enabled = canStart,
        modifier = Modifier.fillMaxWidth().height(54.dp),
        shape = RoundedCornerShape(10.dp),
        colors = ButtonDefaults.buttonColors(containerColor = LiveRed, disabledContainerColor = StudioPanel2)
    ) {
        Icon(Icons.Filled.PlayArrow, null, Modifier.size(21.dp))
        Spacer(Modifier.width(7.dp))
        Text(if (ui.connecting) "CONNEXION…" else "COMMENCER LE DIRECT", style = MaterialTheme.typography.labelLarge)
    }
    if (blockedByOther) Text("Une autre session utilise déjà la caméra.", color = Color(0xFFFFB84D), style = MaterialTheme.typography.bodySmall)
    if (ui.message != null) Text(ui.message!!, color = LiveRed, style = MaterialTheme.typography.bodySmall)
}

