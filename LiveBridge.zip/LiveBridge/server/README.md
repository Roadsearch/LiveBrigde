# Kit serveur (open source)

Ces fichiers sont facultatifs. Ils servent quand tu veux envoyer le flux du téléphone vers **ton propre serveur**
avant OBS ou les plateformes.

## Schéma

```
Téléphone (LiveBridge) ──RTMP/SRT──▶ MediaMTX (PC/serveur) ──▶ OBS (source Média)
                                              └──▶ FFmpeg ──▶ YouTube + Twitch + Facebook
```

## 1. MediaMTX (recommandé : RTMP, SRT, RTSP, HLS et WebRTC dans un seul programme)

```
cd server
docker compose up -d
```

Dans LiveBridge → onglet **Live RTMP** → destination **Autre** :
- RTMP : URL `rtmp://IP_DU_PC:1935/live` et nom du flux `phone`
- SRT (meilleur sur réseau instable) : URL `srt://IP_DU_PC:8890?streamid=publish:live/phone`, clé vide

Dans OBS : Sources → + → **Source Média** → décoche « Fichier local » → entrée
`rtmp://IP_DU_PC:1935/live/phone` (ou `rtsp://IP_DU_PC:8554/live/phone`).

## 2. Multistream avec FFmpeg

Installe FFmpeg, édite les clés dans `restream.sh`, lance `./restream.sh` pendant que le téléphone diffuse vers MediaMTX.

## 3. Autres serveurs compatibles

- **SRS** : `docker compose -f docker-compose.srs.yml up -d`, puis `rtmp://IP_DU_PC/live` + flux `phone`.
- **nginx-rtmp** : `rtmp://IP_DU_PC/live` + nom du flux.
- **Red5** (Java) : publie sur `rtmp://IP_DU_PC/live/phone` ; vérifie que l'application « live » est activée dans ta version.

## Sécurité

Par défaut MediaMTX accepte tout le monde. **N'ouvre pas ces ports sur Internet sans authentification.**
Reste sur ton Wi-Fi, ou passe par un VPN (Tailscale, WireGuard). Pour un accès public, ajoute des
identifiants dans la configuration de MediaMTX (`authInternalUsers`) ou utilise un serveur derrière un proxy TLS.
