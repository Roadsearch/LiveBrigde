#!/usr/bin/env bash
# Multistream avec FFmpeg : reprend le flux reçu par MediaMTX et le renvoie vers plusieurs
# plateformes SANS ré-encoder (-c copy) : presque aucune charge CPU.
#
# 1. Dans l'app : destination "Autre", URL rtmp://IP_DU_PC:1935/live , nom du flux "phone"
# 2. Remplace les clés ci-dessous (supprime les lignes des plateformes inutiles), puis : ./restream.sh
set -euo pipefail

SRC="rtmp://localhost:1935/live/phone"
YOUTUBE="rtmps://a.rtmps.youtube.com:443/live2/CLE_YOUTUBE"
TWITCH="rtmp://live.twitch.tv/app/CLE_TWITCH"
FACEBOOK="rtmps://live-api-s.facebook.com:443/rtmp/CLE_FACEBOOK"

# onfail=ignore : si une plateforme tombe, les autres continuent.
exec ffmpeg -hide_banner -i "$SRC" -map 0 -c copy -f tee \
  "[f=flv:onfail=ignore]$YOUTUBE|[f=flv:onfail=ignore]$TWITCH|[f=flv:onfail=ignore]$FACEBOOK"
