# LiveBridge (Android)

App Android en Kotlin / Jetpack Compose, façon OBS Studio mais pensée mobile, en 3 écrans :

| Écran | Ce que ça fait |
|---|---|
| **Configuration** | Titre, catégorie, destination (YouTube/Twitch/Facebook/serveur perso), micro, réduction de bruit, caméra avant/arrière, aperçu, bouton « Commencer le direct » |
| **Éléments** | Aperçu tactile plein cadre : glisser une source pour la déplacer, pincer pour la redimensionner. Calques en dessous (œil, cadenas, monter/descendre, renommer, supprimer) |
| **En direct** | Tableau de bord : minuteur, débit, réseau, batterie, raccourcis (couper le micro, changer de caméra, enregistrer), bouton « Finir le direct » |

Caméra + micro vers YouTube, Twitch, Facebook ou n'importe quel serveur RTMP/RTMPS/SRT (MediaMTX, SRS,
nginx-rtmp, Red5…), avec logo et texte dans le flux, qualité 480p / 720p / 1080p **en portrait natif**
(pas de bandes noires). Moteur : RootEncoder (`GenericStream`).

VDO.Ninja et OBS (télécommande) ont été retirés à la demande de l'utilisateur : l'app n'ouvre plus
aucun service tiers.

## Lancer le projet

1. Ouvre le dossier dans **Android Studio** (version récente) et laisse la synchronisation Gradle se faire.
   Si Studio propose de mettre à jour AGP / Kotlin / Gradle, accepte.
2. Branche un téléphone Android 8+ (minSdk 26) en mode débogage USB, puis **Run**.
   Un vrai téléphone est nécessaire : l'émulateur n'a pas de vraie caméra.

## Nouveautés v1.3 : refonte complète de l'interface

- **VDO.Ninja et OBS retirés** : plus d'onglets, plus de navigation — un seul flux Configuration → Éléments → En direct.
- **Format portrait natif** (9:16) : la vidéo remplit l'écran, sans bandes noires. Les 3 qualités
  (480p/720p/1080p) sont maintenant en dimensions portrait.
- **Manipulation tactile des sources** : glisser un logo/texte pour le déplacer, pincer à deux doigts
  pour le redimensionner, directement sur l'aperçu. Remplace l'ancien réglage par menu (9 ancrages fixes).
  **Point d'incertitude** : la position libre utilise une méthode de RootEncoder appelée par réflexion
  (car son nom exact varie selon la version de la librairie) ; si elle n'existe pas dans la version
  installée, l'app se replie automatiquement sur l'ancrage fixe le plus proche du point choisi — le
  glisser fonctionne toujours, mais peut « accrocher » à 9 positions plutôt que rester libre. À vérifier
  après ce build.
- **Réduction de bruit / écho** : interrupteur dans Configuration. Désactivée par défaut, car ce
  traitement ajoute un léger délai entre le son et l'image sur beaucoup de téléphones — piste pour
  atténuer le décalage audio/vidéo que tu avais remarqué. **Important à savoir** : le délai total
  jusqu'aux spectateurs (souvent plusieurs secondes sur YouTube/Twitch) est ajouté par la plateforme
  elle-même et ne peut pas être supprimé par l'app ; ce réglage agit uniquement sur un éventuel
  désynchronisation de l'app entre son propre son et sa propre image.

## Depuis v1.1 / v1.2 (toujours présent)

- YouTube en RTMPS par défaut (port 443), bascule RTMP possible.
- Journal (dans Configuration → réglages avancés) : raison exacte d'un échec de connexion, sans jamais
  afficher la clé de stream. Reconnexion automatique (3 essais).
- Enregistrement local MP4 dans `Android/data/com.livebridge/files/Movies/`.
- Serveurs open source : dossier `server/` (MediaMTX, SRS, FFmpeg multistream, notes nginx-rtmp / Red5).

## Limites connues

- Pas de niveaux audio (VU-mètres) : RootEncoder n'expose pas de mesure fiable.
- Pas de nombre de spectateurs ni d'alertes (abonnés, dons) : ça demande de connecter les API officielles
  de YouTube/Twitch (identification du compte, webhooks) — hors du périmètre de cette version.
- Non compilé ni testé ici (pas de SDK Android disponible) : le prochain build GitHub Actions reste le
  vrai test.
