# LiveBridge (Android)

App Android en Kotlin / Jetpack Compose avec 3 onglets :

| Onglet | Ce que ça fait | Technique |
|---|---|---|
| **Live RTMP** | Caméra + micro vers YouTube, Twitch, Facebook ou n'importe quel serveur RTMP/RTMPS/SRT, avec logo et titre dans le flux, qualité 480p / 720p / 1080p | RootEncoder (`GenericStream`) |
| **VDO.Ninja** | Envoie la caméra du téléphone vers **OBS** en WebRTC (faible latence). L'app génère le lien à coller dans OBS | WebView sur `https://vdo.ninja` |
| **OBS** | Télécommande OBS Studio : changer de scène, lancer/arrêter le live, enregistrer | Protocole obs-websocket v5 (OkHttp) |

Aucun code de VDO.Ninja ni d'OBS n'est copié : l'app ouvre le service public VDO.Ninja et parle le
protocole public obs-websocket. Si tu intègres un jour leur code source, vérifie leurs licences
(copyleft GPL / AGPL à ma connaissance).

## Lancer le projet

1. Ouvre le dossier dans **Android Studio** (version récente) et laisse la synchronisation Gradle se faire.
   Si Studio propose de mettre à jour AGP / Kotlin / Gradle, accepte.
2. Branche un téléphone Android 8+ (minSdk 26) en mode débogage USB, puis **Run**.
   Un vrai téléphone est nécessaire : l'émulateur n'a pas de vraie caméra.

## Utiliser avec OBS

**Voir le téléphone dans OBS (onglet VDO.Ninja)**
1. Onglet VDO.Ninja → copie le lien « pour OBS ».
2. OBS → Sources → + → Navigateur → colle le lien (1280 × 720).
3. Sur le téléphone : « Démarrer l'envoi vers OBS ».

**Piloter OBS (onglet OBS)**
1. OBS → Outils → Paramètres du serveur WebSocket → Activer, note le port (4455) et le mot de passe.
2. Téléphone et PC sur le même Wi-Fi. Entre l'IP du PC, le port, le mot de passe.

## Limites de cette v1

- **Non compilé ni testé** : je n'avais pas de SDK Android ici. L'API de RootEncoder 2.8.1 a été vérifiée
  sur sa documentation, mais si un import ou un `override` ne compile pas, corrige-le d'après le README
  de RootEncoder.
- Un seul flux caméra à la fois (RTMP **ou** VDO.Ninja) : la caméra ne peut servir qu'à un flux.
- L'envoi VDO.Ninja passe par une WebView : garde l'écran allumé sur cet onglet pendant l'envoi.
- Le live RTMP continue si tu changes d'onglet. Le comportement en arrière-plan complet
  (écran verrouillé) reste à tester sur tes appareils.
- Pas de partage d'écran, pas de bulle flottante, pas de chat en overlay dans cette version.
- `usesCleartextTraffic=true` est nécessaire pour `ws://` en local. Hors de chez toi, utilise un VPN.
- Les clés de stream et mots de passe sont stockés en clair dans le stockage privé de l'app.
- `targetSdk 36` : pour publier sur le Play Store, justifie caméra, micro et services au premier plan.
