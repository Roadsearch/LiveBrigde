# LiveBridge (Android)

App Android en Kotlin / Jetpack Compose avec 3 onglets :

| Onglet | Ce que ça fait | Technique |
|---|---|---|
| **Studio** | Caméra + micro vers YouTube, Twitch, Facebook ou n'importe quel serveur RTMP/RTMPS/SRT, avec logo et titre dans le flux, qualité 480p / 720p / 1080p | RootEncoder (`GenericStream`) |
| **VDO.Ninja** | Envoie la caméra du téléphone vers **OBS** en WebRTC (faible latence). L'app génère le lien à coller dans OBS | WebView sur `https://vdo.ninja` |
| **OBS** | Télécommande OBS Studio : changer de scène, lancer/arrêter le live, enregistrer | Protocole obs-websocket v5 (OkHttp) |

Aucun code de VDO.Ninja ni d'OBS n'est copié : l'app ouvre le service public VDO.Ninja et parle le
protocole public obs-websocket. Si tu intègres un jour leur code source, vérifie leurs licences
(copyleft GPL / AGPL à ma connaissance).

## Lancer le projet

1. Ouvre le dossier dans **Android Studio** (version récente) et laisse la synchronisation Gradle se faire.
   Si Studio propose de mettre à jour AGP / Kotlin / Gradle, accepte.
2. Branche un téléphone Android 8+ (minSdk 26) en mode débogage USB, puis **Run**.
   Un vrai téléphone est nécessaire : l'émulateur n'a pas de vraie caméra.

## Nouveautés v1.2 : interface façon OBS Studio, pensée mobile

Nouvel onglet **Studio** (remplace « Live RTMP ») :

- **Scènes** : créer, renommer, dupliquer, supprimer ; toucher une scène la bascule en direct.
- **Sources** par scène : Caméra (fond), Image / logo (PNG), Texte. Chaque source a l'œil (afficher/masquer),
  le cadenas (verrouiller), un menu (modifier, monter, descendre, supprimer) et un réglage de position (9 ancrages),
  taille et couleur. Masquer la caméra affiche un fond noir (scène « Pause » fournie).
- **Mélangeur audio** : micro avec coupure (mute).
- **Barre d'état** sur l'aperçu : durée du direct, FPS, débit réel, qualité, batterie, température, réseau.
- **Barre d'action** toujours visible : Démarrer/Arrêter le direct, **REC** (enregistrement local MP4 dans
  `Android/data/com.livebridge/files/Movies/`), Réglages (destination, clé, qualité, journal).
- **Portrait** : aperçu en haut + onglets Scènes / Sources / Audio. **Paysage** : aperçu à gauche,
  Scènes et Sources côte à côte et mélangeur à droite, comme sur la maquette.
- Scènes et sources sauvegardées sur le téléphone.

Pas encore inclus : niveaux audio (VU-mètres), nombre de spectateurs (nécessite l'API de la plateforme),
Mode Studio (aperçu/programme avec transitions), chat en overlay, partage d'écran, déplacement des sources au doigt.

## Depuis v1.1

- **YouTube :** RTMPS par défaut (port 443), bascule RTMP possible, aide pas à pas sur la clé de stream.
- **Journal** (Réglages → « Copier le journal ») : raison exacte d'un échec de connexion, sans jamais afficher
  la clé de stream. **Reconnexion automatique** (3 essais).
- **Serveurs open source** : dossier `server/` (MediaMTX, SRS, FFmpeg multistream, notes nginx-rtmp / Red5).
  Destination « Autre » : n'importe quelle URL rtmp://, rtmps://, srt://.

## Utiliser avec OBS

**Voir le téléphone dans OBS (onglet VDO.Ninja)**
1. Onglet VDO.Ninja → copie le lien « pour OBS ».
2. OBS → Sources → + → Navigateur → colle le lien (1280 × 720).
3. Sur le téléphone : « Démarrer l'envoi vers OBS ».

**Piloter OBS (onglet OBS)**
1. OBS → Outils → Paramètres du serveur WebSocket → Activer, note le port (4455) et le mot de passe.
2. Téléphone et PC sur le même Wi-Fi. Entre l'IP du PC, le port, le mot de passe.

## Limites de cette v1

- **Non compilé ni testé** : je n'avais pas de SDK Android ici. L'API de RootEncoder 2.8.1 a été vérifiée
  sur sa documentation, mais si un import ou un `override` ne compile pas, corrige-le d'après le README
  de RootEncoder.
- Un seul flux caméra à la fois (RTMP **ou** VDO.Ninja) : la caméra ne peut servir qu'à un flux.
- L'envoi VDO.Ninja passe par une WebView : garde l'écran allumé sur cet onglet pendant l'envoi.
- Le live RTMP continue si tu changes d'onglet. Le comportement en arrière-plan complet
  (écran verrouillé) reste à tester sur tes appareils.
- Pas de partage d'écran, pas de bulle flottante, pas de chat en overlay dans cette version.
- `usesCleartextTraffic=true` est nécessaire pour `ws://` en local. Hors de chez toi, utilise un VPN.
- Les clés de stream et mots de passe sont stockés en clair dans le stockage privé de l'app.
- `targetSdk 36` : pour publier sur le Play Store, justifie caméra, micro et services au premier plan.
