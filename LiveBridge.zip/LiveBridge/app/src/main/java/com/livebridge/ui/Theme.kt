package com.livebridge.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Système de design de LiveBridge : palette, typographie, rayons et espacements définis une
 * fois ici et propagés automatiquement à tous les composants Material 3 (boutons, champs,
 * cartes, menus, dialogues) via MaterialTheme dans MainActivity. Modifier une valeur ici la
 * change partout dans l'app, sans avoir à toucher chaque écran.
 */

// ---- Couleurs ----------------------------------------------------------------------------

/** Palette sombre bleu nuit. */
val ObsColors = darkColorScheme(
    primary = Color(0xFF4C8DFF),
    onPrimary = Color.White,
    primaryContainer = Color(0xFF1E3A66),
    secondary = Color(0xFF6C7A99),
    onSecondary = Color.White,
    background = Color(0xFF0D1117),
    onBackground = Color(0xFFE8ECF4),
    surface = Color(0xFF151B26),
    onSurface = Color(0xFFE8ECF4),
    surfaceVariant = Color(0xFF1E2632),
    onSurfaceVariant = Color(0xFFAAB4C7),
    outline = Color(0xFF313D4F),
    error = Color(0xFFFF6259)
)

/** Couleurs sémantiques additionnelles (succès / avertissement / info), non fournies par M3. */
object SemanticColors {
    val success = Color(0xFF34C77B)
    val warning = Color(0xFFF5A524)
    val info = Color(0xFF4C8DFF)
    val onColor = Color.White
}

val LiveRed = Color(0xFFE53935)

// ---- Typographie --------------------------------------------------------------------------

val AppTypography = Typography(
    titleLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 24.sp, lineHeight = 30.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 17.sp, lineHeight = 22.sp),
    titleSmall = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 18.sp),
    bodyLarge = TextStyle(fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 22.sp),
    bodyMedium = TextStyle(fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 16.sp),
    labelLarge = TextStyle(fontWeight = FontWeight.Medium, fontSize = 14.sp, lineHeight = 18.sp),
    labelMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 16.sp),
    labelSmall = TextStyle(fontWeight = FontWeight.Medium, fontSize = 11.sp, lineHeight = 14.sp)
)

// ---- Rayons de bordure --------------------------------------------------------------------

val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(30.dp)
)

// ---- Espacements ---------------------------------------------------------------------------

object Spacing {
    val xs = 4.dp
    val s = 8.dp
    val m = 12.dp
    val l = 16.dp
    val xl = 24.dp
    val xxl = 32.dp
    /** Taille minimale recommandée pour une zone tactile. */
    val touchTarget = 44.dp
}

// ---- Panneau façon carte --------------------------------------------------------------------

/**
 * Panneau façon carte : bandeau de titre + contenu, avec l'élévation tonale Material 3
 * (au lieu d'une couleur de fond posée à la main), pour un rendu cohérent avec le reste de
 * l'app quel que soit le thème système.
 * [scroll] = true : le contenu défile (le panneau doit avoir une hauteur bornée : weight / fillMaxSize).
 */
@Composable
fun Panel(
    title: String,
    modifier: Modifier = Modifier,
    scroll: Boolean = true,
    actions: @Composable RowScope.() -> Unit = {},
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        modifier = modifier,
        shape = MaterialTheme.shapes.medium,
        tonalElevation = 2.dp,
        color = MaterialTheme.colorScheme.surfaceVariant
    ) {
        Column {
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(start = Spacing.m, end = Spacing.xs),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    title.uppercase(),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f).padding(vertical = Spacing.m)
                )
                actions()
            }
            val body = if (scroll) Modifier.verticalScroll(rememberScrollState()) else Modifier
            Column(body.fillMaxWidth().padding(Spacing.xs), content = content)
        }
    }
}

// ---- Bannière de message (succès / erreur / avertissement / info) ------------------------

enum class BannerKind { SUCCESS, ERROR, WARNING, INFO }

@Composable
fun AppBanner(text: String, kind: BannerKind = BannerKind.ERROR, modifier: Modifier = Modifier) {
    val (bg, fg, icon) = when (kind) {
        BannerKind.SUCCESS -> Triple(SemanticColors.success.copy(alpha = 0.16f), SemanticColors.success, "✓")
        BannerKind.ERROR -> Triple(MaterialTheme.colorScheme.error.copy(alpha = 0.16f), MaterialTheme.colorScheme.error, "!")
        BannerKind.WARNING -> Triple(SemanticColors.warning.copy(alpha = 0.16f), SemanticColors.warning, "⚠")
        BannerKind.INFO -> Triple(SemanticColors.info.copy(alpha = 0.16f), SemanticColors.info, "ⓘ")
    }
    Row(
        modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.small)
            .background(bg)
            .padding(horizontal = Spacing.m, vertical = Spacing.s),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(icon, color = fg, fontWeight = FontWeight.Bold, modifier = Modifier.padding(end = Spacing.s))
        Text(text, color = fg, style = MaterialTheme.typography.bodySmall)
    }
}
