package com.livebridge.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/** Palette sombre bleu nuit, dans l'esprit d'OBS Studio. */
val ObsColors = darkColorScheme(
    primary = Color(0xFF3D7BF4),
    onPrimary = Color.White,
    secondary = Color(0xFF5B6B8C),
    onSecondary = Color.White,
    background = Color(0xFF10141C),
    onBackground = Color(0xFFE6E9F0),
    surface = Color(0xFF181E2A),
    onSurface = Color(0xFFE6E9F0),
    surfaceVariant = Color(0xFF232B3B),
    onSurfaceVariant = Color(0xFFB8C0D0),
    error = Color(0xFFFF6B6B)
)

val LiveRed = Color(0xFFE53935)

/**
 * Panneau façon OBS : bandeau de titre + contenu.
 * [scroll] = true : le contenu défile (le panneau doit avoir une hauteur bornée : weight / fillMaxSize).
 */
@Composable
fun Panel(
    title: String,
    modifier: Modifier = Modifier,
    scroll: Boolean = true,
    actions: @Composable RowScope.() -> Unit = {},
    content: @Composable ColumnScope.() -> Unit
) {
    Column(modifier.clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.surfaceVariant)) {
        Row(
            Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .padding(start = 12.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                title.uppercase(),
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.weight(1f).padding(vertical = 12.dp)
            )
            actions()
        }
        val body = if (scroll) Modifier.weight(1f).verticalScroll(rememberScrollState()) else Modifier
        Column(body.fillMaxWidth().padding(4.dp), content = content)
    }
}
