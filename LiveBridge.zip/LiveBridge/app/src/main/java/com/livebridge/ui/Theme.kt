package com.livebridge.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** LiveBridge design system: one source of truth for the whole mobile product. */
val ObsColors = darkColorScheme(
    primary = Color(0xFF6EA8FF),
    onPrimary = Color(0xFF07111F),
    primaryContainer = Color(0xFF18365F),
    onPrimaryContainer = Color(0xFFDCEAFF),
    secondary = Color(0xFF8E9BB3),
    onSecondary = Color(0xFF0B1018),
    background = Color(0xFF080B10),
    onBackground = Color(0xFFF2F5FA),
    surface = Color(0xFF10151D),
    onSurface = Color(0xFFF2F5FA),
    surfaceVariant = Color(0xFF171E28),
    onSurfaceVariant = Color(0xFFAAB5C7),
    outline = Color(0xFF2C3747),
    outlineVariant = Color(0xFF202936),
    error = Color(0xFFFF5B5B),
    onError = Color.White,
    errorContainer = Color(0xFF4A171B),
    onErrorContainer = Color(0xFFFFDAD9)
)

object SemanticColors {
    val success = Color(0xFF35D07F)
    val warning = Color(0xFFFFB84D)
    val info = Color(0xFF6EA8FF)
    val live = Color(0xFFFF4D55)
    val onColor = Color.White
}

val LiveRed = SemanticColors.live

val AppTypography = Typography(
    displaySmall = TextStyle(fontWeight = FontWeight.Bold, fontSize = 34.sp, lineHeight = 40.sp),
    headlineSmall = TextStyle(fontWeight = FontWeight.Bold, fontSize = 25.sp, lineHeight = 31.sp),
    titleLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 22.sp, lineHeight = 28.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 17.sp, lineHeight = 22.sp),
    titleSmall = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 18.sp),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 22.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 17.sp),
    labelLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 18.sp),
    labelMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 16.sp),
    labelSmall = TextStyle(fontWeight = FontWeight.Medium, fontSize = 11.sp, lineHeight = 14.sp)
)

val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(7.dp),
    small = RoundedCornerShape(11.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

object Spacing {
    val xs = 4.dp
    val s = 8.dp
    val m = 12.dp
    val l = 16.dp
    val xl = 24.dp
    val xxl = 32.dp
    val touchTarget = 48.dp
}

@Composable
fun Panel(
    title: String,
    modifier: Modifier = Modifier,
    scroll: Boolean = true,
    actions: @Composable RowScope.() -> Unit = {},
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        modifier = modifier,
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 1.dp
    ) {
        Column {
            Row(
                Modifier.fillMaxWidth().padding(start = Spacing.l, end = Spacing.s),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f).padding(vertical = Spacing.m))
                actions()
            }
            val body = if (scroll) Modifier.verticalScroll(rememberScrollState()) else Modifier
            Column(body.fillMaxWidth().padding(horizontal = Spacing.s, vertical = Spacing.xs), content = content)
        }
    }
}

enum class BannerKind { SUCCESS, ERROR, WARNING, INFO }

@Composable
fun AppBanner(text: String, kind: BannerKind = BannerKind.ERROR, modifier: Modifier = Modifier) {
    val (bg, fg, icon) = when (kind) {
        BannerKind.SUCCESS -> Triple(SemanticColors.success.copy(alpha = .14f), SemanticColors.success, "✓")
        BannerKind.ERROR -> Triple(MaterialTheme.colorScheme.error.copy(alpha = .14f), MaterialTheme.colorScheme.error, "!")
        BannerKind.WARNING -> Triple(SemanticColors.warning.copy(alpha = .14f), SemanticColors.warning, "!")
        BannerKind.INFO -> Triple(SemanticColors.info.copy(alpha = .14f), SemanticColors.info, "i")
    }
    Row(
        modifier.fillMaxWidth().clip(MaterialTheme.shapes.small).background(bg).padding(horizontal = Spacing.m, vertical = Spacing.s),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(icon, color = fg, fontWeight = FontWeight.Bold, modifier = Modifier.padding(end = Spacing.s))
        Text(text, color = fg, style = MaterialTheme.typography.bodySmall)
    }
}
