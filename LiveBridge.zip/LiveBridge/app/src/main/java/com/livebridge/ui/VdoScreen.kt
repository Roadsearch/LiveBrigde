package com.livebridge.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.webkit.WebView
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.livebridge.LiveService
import com.livebridge.Prefs
import com.livebridge.rememberPref
import com.livebridge.vdo.VdoLinks
import java.util.UUID

private val QUALITIES = listOf(0 to "1080p", 1 to "720p", 2 to "360p")

@Composable
fun VdoScreen(
    webView: WebView,
    prefs: Prefs,
    live: Boolean,
    blockedByRtmp: Boolean,
    onLive: (Boolean) -> Unit
) {
    CameraMicGate { VdoContent(webView, prefs, live, blockedByRtmp, onLive) }
}

@Composable
private fun VdoContent(
    webView: WebView,
    prefs: Prefs,
    live: Boolean,
    blockedByRtmp: Boolean,
    onLive: (Boolean) -> Unit
) {
    val ctx = LocalContext.current

    val id = rememberPref(prefs, "vdo_id", "phone-" + UUID.randomUUID().toString().take(8))
    val password = rememberPref(prefs, "vdo_password")
    val label = rememberPref(prefs, "vdo_label", "Android")
    val bitrate = rememberPref(prefs, "vdo_bitrate", "4000")
    val quality = rememberPref(prefs, "vdo_quality", "1")

    val q = quality.value.toIntOrNull() ?: 1
    val pushUrl = VdoLinks.push(id.value, password.value, label.value, bitrate.value.toIntOrNull() ?: 0, q)
    val obsUrl = VdoLinks.view(id.value, password.value)

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            "Envoie la caméra du téléphone vers OBS en WebRTC (faible latence), via VDO.Ninja.",
            style = MaterialTheme.typography.bodyMedium
        )

        Section("Réglages")
        Field(id, "ID du flux (unique)")
        Field(password, "Mot de passe (facultatif)", secret = true)
        Field(label, "Nom affiché")
        Field(bitrate, "Débit vidéo (kb/s)", keyboard = KeyboardType.Number)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            QUALITIES.forEach { (value, name) ->
                FilterChip(
                    selected = q == value,
                    onClick = { if (!live) quality.value = value.toString() },
                    label = { Text(name) }
                )
            }
        }

        Section("Lien pour OBS")
        Text(obsUrl, style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { copy(ctx, obsUrl) }) { Text("Copier") }
            OutlinedButton(onClick = { share(ctx, obsUrl) }) { Text("Partager") }
        }
        Text(
            "Dans OBS : Sources → + → Navigateur → colle ce lien (largeur 1280, hauteur 720).",
            style = MaterialTheme.typography.bodySmall
        )

        if (blockedByRtmp) {
            Text(
                "Arrête d'abord le live RTMP : la caméra ne peut servir qu'à un seul flux.",
                color = MaterialTheme.colorScheme.error
            )
        }

        Button(
            onClick = {
                if (live) {
                    webView.loadUrl("about:blank")
                    LiveService.stop(ctx)
                    onLive(false)
                } else {
                    LiveService.start(ctx, "Live VDO.Ninja")
                    webView.loadUrl(pushUrl)
                    onLive(true)
                }
            },
            enabled = live || (id.value.isNotBlank() && !blockedByRtmp),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (live) Color(0xFFE53935) else MaterialTheme.colorScheme.primary
            ),
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
        ) { Text(if (live) "Arrêter" else "Démarrer l'envoi vers OBS") }

        Text(
            "Reste sur cet écran, allumé, pendant l'envoi. Si la caméra ne démarre pas, " +
                "appuie sur le bouton de démarrage de la page ci-dessous.",
            style = MaterialTheme.typography.bodySmall
        )
        AndroidView(
            factory = { webView },
            modifier = Modifier
                .fillMaxWidth()
                .height(320.dp)
                .clip(RoundedCornerShape(12.dp))
        )
    }
}

private fun copy(ctx: Context, text: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("VDO.Ninja", text))
}

private fun share(ctx: Context, text: String) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    ctx.startActivity(Intent.createChooser(send, null))
}
