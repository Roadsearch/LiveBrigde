package com.livebridge.ui

import android.view.SurfaceHolder
import android.view.SurfaceView
import androidx.compose.foundation.Canvas
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import android.content.res.Configuration
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.livebridge.rtmp.StreamController
import com.livebridge.studio.Scene
import com.livebridge.studio.SourceType
import com.livebridge.studio.StudioStore
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Aperçu 9:16 avec les sources déplaçables et redimensionnables au doigt : un doigt pour
 * déplacer, deux doigts (pincement) pour agrandir/réduire. Actif seulement quand [editable]
 * est vrai (avant le direct) : pendant le direct, l'aperçu reste en lecture seule pour éviter
 * les gestes accidentels.
 */
@Composable
fun PreviewCanvas(
    controller: StreamController,
    store: StudioStore,
    scene: Scene,
    editable: Boolean,
    modifier: Modifier = Modifier,
    loading: Boolean = false
) {
    var boxSize by remember { mutableStateOf(IntSize.Zero) }
    var selected by remember { mutableStateOf<String?>(null) }
    val density = LocalDensity.current
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    Box(
        modifier
            .aspectRatio(if (landscape) 16f / 9f else 9f / 16f)
            .clip(MaterialTheme.shapes.medium)
            .background(Color.Black)
            .onSizeChanged { boxSize = it }
    ) {
        AndroidView(
            factory = { c ->
                val sv = SurfaceView(c)
                sv.holder.addCallback(object : SurfaceHolder.Callback {
                    override fun surfaceCreated(holder: SurfaceHolder) = controller.attachPreview(sv)
                    override fun surfaceChanged(holder: SurfaceHolder, f: Int, w: Int, h: Int) =
                        controller.onPreviewSize(w, h)
                    override fun surfaceDestroyed(holder: SurfaceHolder) = controller.detachPreview()
                })
                sv
            },
            modifier = Modifier.fillMaxSize()
        )

        if (editable && boxSize.width > 0) {
            val movable = scene.sources.filter { it.type != SourceType.CAMERA && it.visible && !it.locked }
            val current = movable.firstOrNull { it.id == selected }

            Box(
                Modifier
                    .fillMaxSize()
                    .pointerInput(movable.map { it.id }) {
                        detectTapGestures { pos ->
                            val px = pos.x / size.width * 100f
                            val py = pos.y / size.height * 100f
                            // Le premier de la liste = celui du dessus (premier plan).
                            selected = movable.firstOrNull { s ->
                                px in s.x..(s.x + s.size) && py in s.y..(s.y + s.size)
                            }?.id
                        }
                    }
                    .let { base ->
                        if (current == null) base else base.pointerInput(current.id, boxSize) {
                            detectTransformGestures { _, pan, zoom, _ ->
                                if (pan != androidx.compose.ui.geometry.Offset.Zero) {
                                    store.moveSource(
                                        current.id,
                                        pan.x / size.width * 100f,
                                        pan.y / size.height * 100f
                                    )
                                }
                                if (abs(zoom - 1f) > 0.003f) {
                                    val newSize = current.size * zoom
                                    store.resizeSource(current.id, newSize)
                                }
                            }
                        }
                    }
            )

            if (current != null) SelectionBox(current.x, current.y, current.size, boxSize, density)
        }

        if (loading) {
            Box(
                Modifier.fillMaxSize().background(Color(0x66000000)),
                contentAlignment = androidx.compose.ui.Alignment.Center
            ) {
                CircularProgressIndicator(color = Color.White)
            }
        }
    }
}

@Composable
private fun SelectionBox(
    x: Float, y: Float, sizePercent: Float,
    boxSize: IntSize, density: androidx.compose.ui.unit.Density
) {
    val primary = MaterialTheme.colorScheme.primary
    Canvas(Modifier.fillMaxSize()) {
        val w = boxSize.width.toFloat()
        val h = boxSize.height.toFloat()
        val left = x / 100f * w
        val top = y / 100f * h
        val side = sizePercent / 100f * w                 // carré approximatif, suffisant comme repère
        val boxH = min(side, h - top)
        translate(left, top) {
            drawRect(
                color = Color(0xFF3D7BF4),
                size = Size(min(side, w - left), max(boxH, 24f)),
                style = Stroke(width = with(density) { 2.dp.toPx() })
            )
        }
    }
}
