package com.livebridge.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.livebridge.rtmp.RtmpUi
import com.livebridge.rtmp.StreamController
import com.livebridge.studio.Anchor
import com.livebridge.studio.Scene
import com.livebridge.studio.Source
import com.livebridge.studio.SourceType
import com.livebridge.studio.StudioState
import com.livebridge.studio.StudioStore

// ---------------------------------------------------------------------------------------------
// Scènes
// ---------------------------------------------------------------------------------------------

private sealed interface SceneDialog {
    object Add : SceneDialog
    data class Rename(val scene: Scene) : SceneDialog
}

@Composable
fun ScenesPanel(store: StudioStore, studio: StudioState, modifier: Modifier = Modifier) {
    var menuFor by remember { mutableStateOf<String?>(null) }
    var dialog by remember { mutableStateOf<SceneDialog?>(null) }

    Panel(
        "Scènes", modifier,
        actions = {
            IconButton(onClick = { dialog = SceneDialog.Add }) {
                Icon(Icons.Filled.Add, contentDescription = "Ajouter une scène")
            }
        }
    ) {
        studio.scenes.forEach { sc ->
            val selected = sc.id == studio.currentId
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.35f) else Color.Transparent)
                    .clickable { store.selectScene(sc.id) }
                    .padding(start = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    sc.name,
                    modifier = Modifier.weight(1f),
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Box {
                    Text("⋯", Modifier.clickable { menuFor = sc.id }.padding(12.dp), fontSize = 18.sp)
                    DropdownMenu(expanded = menuFor == sc.id, onDismissRequest = { menuFor = null }) {
                        DropdownMenuItem(
                            text = { Text("Renommer") },
                            onClick = { menuFor = null; dialog = SceneDialog.Rename(sc) }
                        )
                        DropdownMenuItem(
                            text = { Text("Dupliquer") },
                            onClick = { menuFor = null; store.duplicateScene(sc.id) }
                        )
                        DropdownMenuItem(
                            text = { Text("Supprimer") },
                            enabled = studio.scenes.size > 1,
                            onClick = { menuFor = null; store.deleteScene(sc.id) }
                        )
                    }
                }
            }
        }
    }

    when (val d = dialog) {
        SceneDialog.Add ->
            TextInputDialog("Nouvelle scène", "", { dialog = null }) { store.addScene(it); dialog = null }
        is SceneDialog.Rename ->
            TextInputDialog("Renommer la scène", d.scene.name, { dialog = null }) {
                store.renameScene(d.scene.id, it); dialog = null
            }
        null -> Unit
    }
}

@Composable
fun TextInputDialog(title: String, initial: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var value by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value = value, onValueChange = { value = it }, singleLine = true) },
        confirmButton = { TextButton(onClick = { onConfirm(value) }) { Text("OK") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}

// ---------------------------------------------------------------------------------------------
// Sources
// ---------------------------------------------------------------------------------------------

@Composable
fun SourcesPanel(
    store: StudioStore,
    studio: StudioState,
    controller: StreamController,
    modifier: Modifier = Modifier
) {
    val ctx = LocalContext.current
    var menuFor by remember { mutableStateOf<String?>(null) }
    var addMenu by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<String?>(null) }
    var imageTarget by remember { mutableStateOf<String?>(null) }   // "" = nouvelle image, sinon id à remplacer

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        val target = imageTarget
        imageTarget = null
        if (uri != null && target != null) {
            val bmp = decodeLogo(ctx, uri, 1024)
            if (bmp != null) {
                if (target.isEmpty()) store.addImage("Image", bmp) else store.replaceImage(target, bmp)
            }
        }
    }

    fun pickImage(target: String) {
        imageTarget = target
        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    Panel(
        "Sources", modifier,
        actions = {
            Box {
                IconButton(onClick = { addMenu = true }) {
                    Icon(Icons.Filled.Add, contentDescription = "Ajouter une source")
                }
                DropdownMenu(expanded = addMenu, onDismissRequest = { addMenu = false }) {
                    DropdownMenuItem(
                        text = { Text("Image / logo") },
                        onClick = { addMenu = false; pickImage("") }
                    )
                    DropdownMenuItem(
                        text = { Text("Texte") },
                        onClick = { addMenu = false; store.addText("Texte") }
                    )
                }
            }
        }
    ) {
        studio.current.sources.forEach { s ->
            val isCamera = s.type == SourceType.CAMERA
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    if (s.visible) "👁" else "🚫",
                    Modifier.clickable { store.toggleVisible(s.id) }.padding(10.dp).alpha(if (s.visible) 1f else 0.5f)
                )
                Column(
                    Modifier.weight(1f).clickable(enabled = !isCamera && !s.locked) { editing = s.id }
                ) {
                    Text(s.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        s.type.label,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Text(if (s.locked) "🔒" else "🔓", Modifier.clickable { store.toggleLock(s.id) }.padding(10.dp))
                Box {
                    Text("⋯", Modifier.clickable { menuFor = s.id }.padding(10.dp), fontSize = 18.sp)
                    DropdownMenu(expanded = menuFor == s.id, onDismissRequest = { menuFor = null }) {
                        if (isCamera) {
                            DropdownMenuItem(
                                text = { Text("Changer de caméra") },
                                onClick = { menuFor = null; controller.switchCamera() }
                            )
                        } else {
                            DropdownMenuItem(
                                text = { Text("Modifier") }, enabled = !s.locked,
                                onClick = { menuFor = null; editing = s.id }
                            )
                            DropdownMenuItem(
                                text = { Text("Monter") }, enabled = !s.locked,
                                onClick = { menuFor = null; store.moveSource(s.id, -1) }
                            )
                            DropdownMenuItem(
                                text = { Text("Descendre") }, enabled = !s.locked,
                                onClick = { menuFor = null; store.moveSource(s.id, 1) }
                            )
                            DropdownMenuItem(
                                text = { Text("Supprimer") }, enabled = !s.locked,
                                onClick = { menuFor = null; store.removeSource(s.id) }
                            )
                        }
                    }
                }
            }
        }
    }

    val editingSource = studio.current.sources.firstOrNull { it.id == editing }
    if (editingSource != null) {
        SourceEditDialog(
            source = editingSource,
            onPickImage = { pickImage(editingSource.id) },
            onDismiss = { editing = null },
            onSave = { store.updateSource(it); editing = null }
        )
    }
}

private val TEXT_COLORS = listOf(
    -1,                      // blanc
    0xFFFFEB3B.toInt(),      // jaune
    0xFF00E5FF.toInt(),      // cyan
    0xFFFF5252.toInt(),      // rouge
    0xFF000000.toInt()       // noir
)

private val ANCHOR_ROWS = listOf(
    listOf(Anchor.TOP_LEFT, Anchor.TOP, Anchor.TOP_RIGHT),
    listOf(Anchor.LEFT, Anchor.CENTER, Anchor.RIGHT),
    listOf(Anchor.BOTTOM_LEFT, Anchor.BOTTOM, Anchor.BOTTOM_RIGHT)
)

@Composable
private fun SourceEditDialog(
    source: Source,
    onPickImage: () -> Unit,
    onDismiss: () -> Unit,
    onSave: (Source) -> Unit
) {
    var name by remember(source.id) { mutableStateOf(source.name) }
    var text by remember(source.id) { mutableStateOf(source.text) }
    var anchor by remember(source.id) { mutableStateOf(source.anchor) }
    var size by remember(source.id) { mutableStateOf(source.size.toFloat()) }
    var textSize by remember(source.id) { mutableStateOf(source.textSize.toFloat()) }
    var color by remember(source.id) { mutableStateOf(source.color) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Modifier la source") },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = name, onValueChange = { name = it },
                    label = { Text("Nom") }, singleLine = true
                )
                if (source.type == SourceType.TEXT) {
                    OutlinedTextField(value = text, onValueChange = { text = it }, label = { Text("Texte") })
                    Text("Taille : ${textSize.toInt()}")
                    Slider(value = textSize, onValueChange = { textSize = it }, valueRange = 20f..150f)
                    Text("Couleur")
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        TEXT_COLORS.forEach { c ->
                            Box(
                                Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(Color(c))
                                    .border(
                                        if (c == color) 3.dp else 1.dp,
                                        if (c == color) MaterialTheme.colorScheme.primary else Color.Gray,
                                        CircleShape
                                    )
                                    .clickable { color = c }
                            )
                        }
                    }
                } else {
                    OutlinedButton(onClick = onPickImage) {
                        Text(if (source.hasImage) "Changer l'image" else "Choisir une image")
                    }
                    Text("Taille : ${size.toInt()} % de la largeur")
                    Slider(value = size, onValueChange = { size = it }, valueRange = 5f..100f)
                }
                Text("Position")
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    ANCHOR_ROWS.forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            row.forEach { a ->
                                FilterChip(
                                    selected = a == anchor,
                                    onClick = { anchor = a },
                                    label = { Text(a.symbol) }
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(
                    source.copy(
                        name = name.ifBlank { source.name },
                        text = text,
                        anchor = anchor,
                        size = size.toInt(),
                        textSize = textSize.toInt(),
                        color = color
                    )
                )
            }) { Text("OK") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}

// ---------------------------------------------------------------------------------------------
// Mélangeur audio
// ---------------------------------------------------------------------------------------------

@Composable
fun MixerPanel(controller: StreamController, ui: RtmpUi, modifier: Modifier = Modifier) {
    Panel("Mélangeur audio", modifier, scroll = false) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("🎤", fontSize = 20.sp, modifier = Modifier.padding(end = 10.dp))
            Column(Modifier.weight(1f)) {
                Text("Micro")
                Text(
                    if (ui.micMuted) "Coupé" else "Actif",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (ui.micMuted) MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(checked = !ui.micMuted, onCheckedChange = { controller.setMicMuted(!it) })
        }
    }
}
