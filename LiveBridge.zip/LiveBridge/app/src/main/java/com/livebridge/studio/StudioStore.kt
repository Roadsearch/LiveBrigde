package com.livebridge.studio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.livebridge.Prefs
import com.livebridge.rtmp.StreamController
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File

/**
 * Scènes et sources façon OBS, sauvegardées sur le téléphone.
 * Chaque modification de la scène active est appliquée immédiatement au flux.
 */
class StudioStore(
    context: Context,
    private val prefs: Prefs,
    private val controller: StreamController
) {
    private val dir = File(context.filesDir, "sources").apply { mkdirs() }
    private val bitmaps = HashMap<String, Bitmap>()

    private val _state = MutableStateFlow(load())
    val state: StateFlow<StudioState> = _state.asStateFlow()

    init {
        // Ré-applique la scène active à chaque (re)démarrage de l'aperçu.
        controller.onPreviewStarted = { render() }
    }

    private fun load(): StudioState =
        prefs.get("studio").takeIf { it.isNotBlank() }?.let { parseStudio(it) } ?: defaultState()

    private fun commit(s: StudioState, rerender: Boolean = true) {
        _state.value = s
        prefs.put("studio", s.toJson())
        if (rerender) render()
    }

    fun render() {
        controller.renderScene(_state.value.current) { imageFor(it) }
    }

    private fun imageFor(s: Source): Bitmap? {
        if (!s.hasImage) return null
        bitmaps[s.id]?.let { return it }
        val bmp = BitmapFactory.decodeFile(File(dir, "${s.id}.png").absolutePath) ?: return null
        bitmaps[s.id] = bmp
        return bmp
    }

    private fun saveImage(id: String, bmp: Bitmap) {
        File(dir, "$id.png").outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bitmaps[id] = bmp
    }

    private fun deleteImage(id: String) {
        File(dir, "$id.png").delete()
        bitmaps.remove(id)
    }

    // ---- Scènes --------------------------------------------------------------------------

    fun selectScene(id: String) {
        if (_state.value.currentId != id) commit(_state.value.copy(currentId = id))
    }

    fun addScene(name: String) {
        val sc = Scene(
            name = name.ifBlank { "Scène" },
            sources = listOf(Source(name = "Caméra", type = SourceType.CAMERA))
        )
        commit(StudioState(_state.value.scenes + sc, sc.id))
    }

    fun renameScene(id: String, name: String) {
        if (name.isBlank()) return
        commit(
            _state.value.copy(scenes = _state.value.scenes.map { if (it.id == id) it.copy(name = name.trim()) else it }),
            rerender = false
        )
    }

    fun duplicateScene(id: String) {
        val src = _state.value.scenes.firstOrNull { it.id == id } ?: return
        val copies = src.sources.map { s ->
            val newSource = s.copy(id = newId())
            if (s.hasImage) {
                File(dir, "${s.id}.png").takeIf { it.exists() }
                    ?.copyTo(File(dir, "${newSource.id}.png"), overwrite = true)
            }
            newSource
        }
        val sc = Scene(name = src.name + " (copie)", sources = copies)
        commit(StudioState(_state.value.scenes + sc, sc.id))
    }

    fun deleteScene(id: String) {
        val s = _state.value
        if (s.scenes.size <= 1) return
        s.scenes.firstOrNull { it.id == id }?.sources?.forEach { if (it.hasImage) deleteImage(it.id) }
        val rest = s.scenes.filter { it.id != id }
        commit(StudioState(rest, if (s.currentId == id) rest.first().id else s.currentId))
    }

    // ---- Sources de la scène active ------------------------------------------------------

    private fun editCurrent(rerender: Boolean = true, transform: (Scene) -> Scene) {
        val s = _state.value
        commit(
            s.copy(scenes = s.scenes.map { if (it.id == s.currentId) transform(it) else it }),
            rerender
        )
    }

    private fun mapSource(id: String, f: (Source) -> Source): (Scene) -> Scene = { sc ->
        sc.copy(sources = sc.sources.map { if (it.id == id) f(it) else it })
    }

    fun toggleVisible(id: String) = editCurrent(transform = mapSource(id) { it.copy(visible = !it.visible) })

    fun toggleLock(id: String) = editCurrent(rerender = false, transform = mapSource(id) { it.copy(locked = !it.locked) })

    fun updateSource(updated: Source) = editCurrent(transform = mapSource(updated.id) { updated })

    fun addText(name: String) {
        val src = Source(
            name = name, type = SourceType.TEXT, text = "Mon texte",
            anchor = Anchor.BOTTOM, textSize = 50
        )
        editCurrent { it.copy(sources = ensureCamera(listOf(src) + it.sources)) }
    }

    fun addImage(name: String, bmp: Bitmap) {
        val id = newId()
        saveImage(id, bmp)
        val src = Source(
            id = id, name = name, type = SourceType.IMAGE, hasImage = true,
            anchor = Anchor.TOP_RIGHT, size = 15
        )
        editCurrent { it.copy(sources = ensureCamera(listOf(src) + it.sources)) }
    }

    fun replaceImage(id: String, bmp: Bitmap) {
        saveImage(id, bmp)
        editCurrent(transform = mapSource(id) { it.copy(hasImage = true) })
    }

    fun removeSource(id: String) {
        val target = _state.value.current.sources.firstOrNull { it.id == id } ?: return
        if (target.type == SourceType.CAMERA) return
        if (target.hasImage) deleteImage(id)
        editCurrent { it.copy(sources = it.sources.filter { s -> s.id != id }) }
    }

    /** delta = -1 : monter (vers le premier plan), +1 : descendre. La caméra reste au fond. */
    fun moveSource(id: String, delta: Int) = editCurrent { sc ->
        val list = sc.sources.toMutableList()
        val i = list.indexOfFirst { it.id == id }
        val j = i + delta
        if (i < 0 || j < 0 || j >= list.size) return@editCurrent sc
        if (list[i].type == SourceType.CAMERA || list[j].type == SourceType.CAMERA) return@editCurrent sc
        val tmp = list[i]; list[i] = list[j]; list[j] = tmp
        sc.copy(sources = list)
    }
}
