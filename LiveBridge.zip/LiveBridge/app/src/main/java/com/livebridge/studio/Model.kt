package com.livebridge.studio

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

fun newId(): String = UUID.randomUUID().toString().take(8)

enum class SourceType(val label: String) {
    CAMERA("Caméra"),
    IMAGE("Image"),
    TEXT("Texte")
}

/** Ancrage sur l'image. Les noms correspondent à ceux de TranslateTo (RootEncoder). */
enum class Anchor(val symbol: String) {
    TOP_LEFT("↖"), TOP("↑"), TOP_RIGHT("↗"),
    LEFT("←"), CENTER("●"), RIGHT("→"),
    BOTTOM_LEFT("↙"), BOTTOM("↓"), BOTTOM_RIGHT("↘")
}

data class Source(
    val id: String = newId(),
    val name: String,
    val type: SourceType,
    val visible: Boolean = true,
    val locked: Boolean = false,
    val text: String = "",
    val hasImage: Boolean = false,      // fichier filesDir/sources/<id>.png
    val anchor: Anchor = Anchor.CENTER,
    val size: Int = 20,                 // image : largeur en % de l'écran
    val textSize: Int = 40,             // texte : taille
    val color: Int = -1                 // texte : couleur ARGB (-1 = blanc)
)

data class Scene(
    val id: String = newId(),
    val name: String,
    val sources: List<Source>           // index 0 = au premier plan (comme OBS)
)

data class StudioState(val scenes: List<Scene>, val currentId: String) {
    val current: Scene get() = scenes.firstOrNull { it.id == currentId } ?: scenes.first()
}

fun defaultState(): StudioState {
    val main = Scene(name = "Caméra", sources = listOf(Source(name = "Caméra", type = SourceType.CAMERA)))
    val pause = Scene(
        name = "Pause",
        sources = listOf(
            Source(
                name = "Message", type = SourceType.TEXT,
                text = "Je reviens tout de suite", anchor = Anchor.CENTER, textSize = 80
            ),
            Source(name = "Caméra", type = SourceType.CAMERA, visible = false)
        )
    )
    return StudioState(listOf(main, pause), main.id)
}

/** La caméra est toujours la source du fond (dernière de la liste). */
fun ensureCamera(sources: List<Source>): List<Source> {
    val cam = sources.firstOrNull { it.type == SourceType.CAMERA }
        ?: Source(name = "Caméra", type = SourceType.CAMERA)
    return sources.filter { it.type != SourceType.CAMERA } + cam
}

fun StudioState.toJson(): String {
    val scenesJson = JSONArray()
    for (sc in scenes) {
        val sourcesJson = JSONArray()
        for (s in sc.sources) {
            sourcesJson.put(
                JSONObject()
                    .put("id", s.id).put("name", s.name).put("type", s.type.name)
                    .put("visible", s.visible).put("locked", s.locked)
                    .put("text", s.text).put("hasImage", s.hasImage)
                    .put("anchor", s.anchor.name).put("size", s.size)
                    .put("textSize", s.textSize).put("color", s.color)
            )
        }
        scenesJson.put(JSONObject().put("id", sc.id).put("name", sc.name).put("sources", sourcesJson))
    }
    return JSONObject().put("current", currentId).put("scenes", scenesJson).toString()
}

fun parseStudio(json: String): StudioState? = runCatching {
    val root = JSONObject(json)
    val arr = root.getJSONArray("scenes")
    val scenes = mutableListOf<Scene>()
    for (i in 0 until arr.length()) {
        val o = arr.getJSONObject(i)
        val sa = o.getJSONArray("sources")
        val sources = mutableListOf<Source>()
        for (j in 0 until sa.length()) {
            val so = sa.getJSONObject(j)
            sources += Source(
                id = so.getString("id"),
                name = so.getString("name"),
                type = SourceType.valueOf(so.getString("type")),
                visible = so.optBoolean("visible", true),
                locked = so.optBoolean("locked", false),
                text = so.optString("text"),
                hasImage = so.optBoolean("hasImage", false),
                anchor = Anchor.valueOf(so.optString("anchor", "CENTER")),
                size = so.optInt("size", 20),
                textSize = so.optInt("textSize", 40),
                color = so.optInt("color", -1)
            )
        }
        scenes += Scene(o.getString("id"), o.getString("name"), ensureCamera(sources))
    }
    if (scenes.isEmpty()) return@runCatching null
    val cur = root.optString("current")
    StudioState(scenes, if (scenes.any { it.id == cur }) cur else scenes.first().id)
}.getOrNull()
