package com.livebridge.ui

import android.graphics.Bitmap
import android.view.SurfaceHolder
import android.view.SurfaceView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.livebridge.Prefs
import com.livebridge.rememberPref
import com.livebridge.rtmp.Quality
import com.livebridge.rtmp.StreamController

private val PLATFORMS = linkedMapOf(
    "YouTube" to "rtmp://a.rtmp.youtube.com/live2",
    "Twitch" to "rtmp://live.twitch.tv/app",
    "Facebook" to "rtmps://live-api-s.facebook.com:443/rtmp",
    "Autre" to ""
)

@Composable
fun RtmpScreen(controller: StreamController, prefs: Prefs, blockedByVdo: Boolean) {
    CameraMicGate { RtmpContent(controller, prefs, blockedByVdo) }
}

@Composable
private fun RtmpContent(controller: StreamController, prefs: Prefs, blockedByVdo: Boolean) {
    val ctx = LocalContext.current
    val ui by controller.ui.collectAsState()

    var platform by rememberPref(prefs, "rtmp_platform", "YouTube")
    val customBase = rememberPref(prefs, "rtmp_custom_base")
    val key = rememberPref(prefs, "rtmp_key")
    val title = rememberPref(prefs, "overlay_title")
    var logo by remember { mutableStateOf<Bitmap?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) logo = decodeLogo(ctx, uri)
    }

    val base = if (platform == "Autre") customBase.value.trim() else PLATFORMS[platform].orEmpty()
    val fullUrl = when {
        base.isBlank() -> ""
        key.value.isBlank() -> base
        else -> base.trimEnd('/') + "/" + key.value.trim().trimStart('/')
    }
    val live = ui.streaming || ui.connecting

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        AndroidView(
            factory = { c ->
                val sv = SurfaceView(c)
                sv.holder.addCallback(object : SurfaceHolder.Callback {
                    override fun surfaceCreated(holder: SurfaceHolder) = controller.attachPreview(sv)
                    override fun surfaceChanged(holder: SurfaceHolder, f: Int, w: Int, h: Int) =
                        controller.onPreviewSize(w, h)
                    override fun surfaceDestroyed(holder: SurfaceHolder) = controller.detachPreview()
                })
                sv
            },
            modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(12.dp))
        )

        Text(
            when {
                ui.streaming -> "● EN DIRECT · ${ui.bitrateKbps} kb/s"
                ui.connecting -> "Connexion au serveur…"
                else -> "Prêt"
            },
            style = MaterialTheme.typography.titleMedium,
            color = if (ui.streaming) Color(0xFFE53935) else MaterialTheme.colorScheme.onSurface
        )
        ui.message?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        if (blockedByVdo) {
            Text("Arrête d'abord le live VDO.Ninja : la caméra ne peut servir qu'à un seul flux.",
                color = MaterialTheme.colorScheme.error)
        }

        Section("Destination")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PLATFORMS.keys.forEach { name ->
                FilterChip(
                    selected = platform == name,
                    onClick = { if (!live) platform = name },
                    label = { Text(name) }
                )
            }
        }
        if (platform == "Autre") {
            Field(customBase, "URL du serveur (rtmp://, rtmps://, srt://…)")
        }
        Field(key, "Clé de stream", secret = true)

        Section("Qualité")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Quality.entries.forEach { q ->
                FilterChip(
                    selected = ui.quality == q,
                    onClick = { controller.setQuality(q) },
                    enabled = !live,
                    label = { Text(q.label) }
                )
            }
        }

        Section("Overlays dans le flux")
        Field(title, "Titre affiché en bas")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            }) { Text(if (logo == null) "Choisir un logo" else "Logo choisi ✓") }
            Button(onClick = { controller.setOverlays(title.value, logo) }) { Text("Appliquer") }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 12.dp)) {
            OutlinedButton(onClick = { controller.switchCamera() }) { Text("Changer de caméra") }
            Button(
                onClick = { if (live) controller.stop() else controller.start(fullUrl) },
                enabled = live || (fullUrl.isNotBlank() && !blockedByVdo),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (live) Color(0xFFE53935) else MaterialTheme.colorScheme.primary
                ),
                modifier = Modifier.weight(1f)
            ) { Text(if (live) "Arrêter le live" else "Démarrer le live") }
        }
    }
}
