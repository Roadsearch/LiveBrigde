package com.livebridge.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.view.SurfaceHolder
import android.view.SurfaceView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.livebridge.Prefs
import com.livebridge.rememberPref
import com.livebridge.rtmp.Quality
import com.livebridge.rtmp.SceneKind
import com.livebridge.rtmp.StreamController

private val PLATFORMS = linkedMapOf(
    "YouTube" to "",                                   // calculé selon RTMP / RTMPS
    "Twitch" to "rtmp://live.twitch.tv/app",
    "Facebook" to "rtmps://live-api-s.facebook.com:443/rtmp",
    "Autre" to ""                                      // serveur perso : MediaMTX, SRS, Red5, nginx-rtmp…
)

private const val YOUTUBE_HELP =
    "Clé : YouTube Studio (sur ordinateur ou en « site pour ordinateur ») → Créer → Passer en direct " +
        "→ onglet Diffusion → copie la « Clé de stream ». La chaîne doit avoir la diffusion en direct " +
        "activée (jusqu'à 24 h après la vérification). Après ~15 s de connexion, YouTube doit afficher " +
        "l'aperçu ; appuie alors sur « Passer en direct » dans YouTube Studio."

@Composable
fun RtmpScreen(controller: StreamController, prefs: Prefs, blockedByVdo: Boolean) {
    CameraMicGate { RtmpContent(controller, prefs, blockedByVdo) }
}

@Composable
private fun RtmpContent(controller: StreamController, prefs: Prefs, blockedByVdo: Boolean) {
    val ctx = LocalContext.current
    val ui by controller.ui.collectAsState()
    val logs by controller.logs.collectAsState()

    var platform by rememberPref(prefs, "rtmp_platform", "YouTube")
    var ytTls by rememberPref(prefs, "rtmp_yt_tls", "1")
    val customBase = rememberPref(prefs, "rtmp_custom_base")
    val key = rememberPref(prefs, "rtmp_key")
    val title = rememberPref(prefs, "overlay_title")
    val brbText = rememberPref(prefs, "brb_text", "Je reviens tout de suite")
    var logo by remember { mutableStateOf<Bitmap?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            logo = decodeLogo(ctx, uri)
            controller.applyScene(controller.ui.value.scene, title.value, logo, brbText.value)
        }
    }

    val base = when (platform) {
        "YouTube" ->
            if (ytTls == "1") "rtmps://a.rtmps.youtube.com:443/live2" else "rtmp://a.rtmp.youtube.com/live2"
        "Autre" -> customBase.value.trim()
        else -> PLATFORMS[platform].orEmpty()
    }
    val fullUrl = when {
        base.isBlank() -> ""
        key.value.isBlank() -> base
        else -> base.trimEnd('/') + "/" + key.value.trim().trimStart('/')
    }
    val live = ui.streaming || ui.connecting

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        AndroidView(
            factory = { c ->
                val sv = SurfaceView(c)
                sv.holder.addCallback(object : SurfaceHolder.Callback {
                    override fun surfaceCreated(holder: SurfaceHolder) = controller.attachPreview(sv)
                    override fun surfaceChanged(holder: SurfaceHolder, f: Int, w: Int, h: Int) =
                        controller.onPreviewSize(w, h)
                    override fun surfaceDestroyed(holder: SurfaceHolder) = controller.detachPreview()
                })
                sv
            },
            modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(12.dp))
        )

        Text(
            when {
                ui.streaming -> "● EN DIRECT · ${ui.bitrateKbps} kb/s"
                ui.connecting -> "Connexion au serveur…"
                else -> "Prêt"
            },
            style = MaterialTheme.typography.titleMedium,
            color = if (ui.streaming) Color(0xFFE53935) else MaterialTheme.colorScheme.onSurface
        )
        ui.message?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        if (blockedByVdo) {
            Text(
                "Arrête d'abord le live VDO.Ninja : la caméra ne peut servir qu'à un seul flux.",
                color = MaterialTheme.colorScheme.error
            )
        }

        Section("Destination")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PLATFORMS.keys.forEach { name ->
                FilterChip(
                    selected = platform == name,
                    onClick = { if (!live) platform = name },
                    label = { Text(name) }
                )
            }
        }
        if (platform == "YouTube") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = ytTls == "1",
                    onClick = { if (!live) ytTls = "1" },
                    label = { Text("RTMPS (recommandé)") }
                )
                FilterChip(
                    selected = ytTls != "1",
                    onClick = { if (!live) ytTls = "0" },
                    label = { Text("RTMP") }
                )
            }
            Text(YOUTUBE_HELP, style = MaterialTheme.typography.bodySmall)
        }
        if (platform == "Autre") {
            Field(customBase, "URL du serveur")
            Text(
                "Exemples : rtmp://192.168.1.10:1935/live (MediaMTX, SRS, Red5, nginx-rtmp) · " +
                    "srt://192.168.1.10:8890?streamid=publish:live/phone (MediaMTX, SRT, sans clé ci-dessous).",
                style = MaterialTheme.typography.bodySmall
            )
        }
        Field(key, if (platform == "Autre") "Nom du flux / clé (facultatif)" else "Clé de stream", secret = true)

        Section("Qualité")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Quality.entries.forEach { q ->
                FilterChip(
                    selected = ui.quality == q,
                    onClick = { controller.setQuality(q) },
                    enabled = !live,
                    label = { Text(q.label) }
                )
            }
        }

        Section("Scènes (comme OBS)")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SceneKind.entries.forEach { kind ->
                FilterChip(
                    selected = ui.scene == kind,
                    onClick = { controller.applyScene(kind, title.value, logo, brbText.value) },
                    label = { Text(kind.label) }
                )
            }
        }
        Field(title, "Titre affiché en bas (scène Logo + titre)")
        Field(brbText, "Texte de la scène Pause")
        OutlinedButton(onClick = {
            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }) { Text(if (logo == null) "Choisir un logo" else "Logo choisi ✓") }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 12.dp)) {
            OutlinedButton(onClick = { controller.switchCamera() }) { Text("Changer de caméra") }
            Button(
                onClick = { if (live) controller.stop() else controller.start(fullUrl) },
                enabled = live || (fullUrl.isNotBlank() && !blockedByVdo),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (live) Color(0xFFE53935) else MaterialTheme.colorScheme.primary
                ),
                modifier = Modifier.weight(1f)
            ) { Text(if (live) "Arrêter le live" else "Démarrer le live") }
        }

        Section("Journal")
        Box(
            Modifier
                .fillMaxWidth()
                .height(170.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF1B1B1B))
                .padding(8.dp)
        ) {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (logs.isEmpty()) Text("Aucun événement.", style = MaterialTheme.typography.bodySmall)
                logs.asReversed().forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { copyText(ctx, logs.joinToString("\n")) }) { Text("Copier le journal") }
            OutlinedButton(onClick = { controller.clearLogs() }) { Text("Effacer") }
        }
    }
}

private fun copyText(ctx: Context, text: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("LiveBridge", text))
}
