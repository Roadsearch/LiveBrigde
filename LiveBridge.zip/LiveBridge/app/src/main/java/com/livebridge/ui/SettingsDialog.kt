package com.livebridge.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.livebridge.rtmp.Quality
import com.livebridge.rtmp.RtmpUi
import com.livebridge.rtmp.StreamController

val PLATFORMS = listOf("YouTube", "Twitch", "Facebook", "Autre")

private const val YOUTUBE_HELP =
    "Clé : YouTube Studio (sur ordinateur ou en « site pour ordinateur ») → Créer → Passer en direct " +
        "→ onglet Diffusion → copie la « Clé de stream ». La chaîne doit avoir la diffusion en direct " +
        "activée (jusqu'à 24 h après la vérification). Après ~15 s de connexion, YouTube doit afficher " +
        "l'aperçu ; appuie alors sur « Passer en direct » dans YouTube Studio."

/** URL complète d'envoi, d'après la destination choisie. Vide si incomplète. */
fun rtmpUrl(platform: String, ytTls: String, customBase: String, key: String): String {
    val base = when (platform) {
        "YouTube" ->
            if (ytTls == "1") "rtmps://a.rtmps.youtube.com:443/live2" else "rtmp://a.rtmp.youtube.com/live2"
        "Twitch" -> "rtmp://live.twitch.tv/app"
        "Facebook" -> "rtmps://live-api-s.facebook.com:443/rtmp"
        else -> customBase.trim()
    }
    return when {
        base.isBlank() -> ""
        key.isBlank() -> base
        else -> base.trimEnd('/') + "/" + key.trim().trimStart('/')
    }
}

@Composable
fun SettingsDialog(
    controller: StreamController,
    ui: RtmpUi,
    logs: List<String>,
    platform: MutableState<String>,
    ytTls: MutableState<String>,
    customBase: MutableState<String>,
    key: MutableState<String>,
    onDismiss: () -> Unit
) {
    val ctx = LocalContext.current
    var selected by platform
    var tls by ytTls
    val live = ui.streaming || ui.connecting || ui.recording

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth(0.94f).fillMaxHeight(0.92f)
        ) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Text("Réglages du direct", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                    TextButton(onClick = onDismiss) { Text("Fermer") }
                }
                Column(
                    Modifier.weight(1f).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Section("Destination")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PLATFORMS.forEach { name ->
                            FilterChip(
                                selected = selected == name,
                                onClick = { if (!live) selected = name },
                                label = { Text(name) }
                            )
                        }
                    }
                    if (selected == "YouTube") {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = tls == "1",
                                onClick = { if (!live) tls = "1" },
                                label = { Text("RTMPS (recommandé)") }
                            )
                            FilterChip(
                                selected = tls != "1",
                                onClick = { if (!live) tls = "0" },
                                label = { Text("RTMP") }
                            )
                        }
                        Text(YOUTUBE_HELP, style = MaterialTheme.typography.bodySmall)
                    }
                    if (selected == "Autre") {
                        Field(customBase, "URL du serveur")
                        Text(
                            "Exemples : rtmp://192.168.1.10:1935/live (MediaMTX, SRS, Red5, nginx-rtmp) · " +
                                "srt://192.168.1.10:8890?streamid=publish:live/phone (MediaMTX, SRT, sans clé ci-dessous).",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Field(
                        key,
                        if (selected == "Autre") "Nom du flux / clé (facultatif)" else "Clé de stream",
                        secret = true
                    )

                    Section("Qualité")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Quality.entries.forEach { q ->
                            FilterChip(
                                selected = ui.quality == q,
                                onClick = { controller.setQuality(q) },
                                enabled = !live,
                                label = { Text(q.label) }
                            )
                        }
                    }
                    if (live) Text("Arrête le direct et l'enregistrement pour changer ces réglages.",
                        style = MaterialTheme.typography.bodySmall)

                    ui.lastRecordPath?.let {
                        Section("Dernier enregistrement")
                        Text(it, style = MaterialTheme.typography.bodySmall)
                    }

                    Section("Journal")
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(170.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF0B0E14))
                            .padding(8.dp)
                    ) {
                        Column(Modifier.verticalScroll(rememberScrollState())) {
                            if (logs.isEmpty()) Text("Aucun événement.", style = MaterialTheme.typography.bodySmall)
                            logs.asReversed().forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { copyText(ctx, logs.joinToString("\n")) }) { Text("Copier le journal") }
                        OutlinedButton(onClick = { controller.clearLogs() }) { Text("Effacer") }
                    }
                }
            }
        }
    }
}

private fun copyText(ctx: Context, text: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("LiveBridge", text))
}
