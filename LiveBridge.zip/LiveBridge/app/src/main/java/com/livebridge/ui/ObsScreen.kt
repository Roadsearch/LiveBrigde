package com.livebridge.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.livebridge.Prefs
import com.livebridge.obs.ObsClient
import com.livebridge.rememberPref

@Composable
fun ObsScreen(obs: ObsClient, prefs: Prefs) {
    val s by obs.state.collectAsState()
    val host = rememberPref(prefs, "obs_host", "192.168.1.10")
    val port = rememberPref(prefs, "obs_port", "4455")
    val password = rememberPref(prefs, "obs_password")
    val red = Color(0xFFE53935)

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            "Pilote OBS Studio à distance : scènes, live, enregistrement.",
            style = MaterialTheme.typography.bodyMedium
        )
        Text(
            "Dans OBS : Outils → Paramètres du serveur WebSocket → Activer, puis note le port " +
                "et le mot de passe. Téléphone et PC doivent être sur le même Wi-Fi.",
            style = MaterialTheme.typography.bodySmall
        )

        if (!s.connected) {
            Field(host, "IP du PC (ex. 192.168.1.10)", keyboard = KeyboardType.Uri)
            Field(port, "Port", keyboard = KeyboardType.Number)
            Field(password, "Mot de passe OBS", secret = true)
            Button(
                onClick = { obs.connect(host.value, port.value.toIntOrNull() ?: 4455, password.value) },
                enabled = !s.connecting && host.value.isNotBlank(),
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (s.connecting) "Connexion…" else "Se connecter") }
        } else {
            Text("Connecté à OBS ✓", style = MaterialTheme.typography.titleMedium)

            Section("Diffusion")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { if (s.streaming) obs.stopStream() else obs.startStream() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (s.streaming) red else MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.weight(1f)
                ) { Text(if (s.streaming) "■ Stop live" else "● Lancer le live") }
                Button(
                    onClick = { if (s.recording) obs.stopRecord() else obs.startRecord() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (s.recording) red else MaterialTheme.colorScheme.secondary
                    ),
                    modifier = Modifier.weight(1f)
                ) { Text(if (s.recording) "■ Stop rec" else "● Enregistrer") }
            }

            Section("Scènes")
            if (s.scenes.isEmpty()) Text("Aucune scène.")
            s.scenes.forEach { name ->
                val active = name == s.currentScene
                if (active) {
                    FilledTonalButton(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text("▶ $name") }
                } else {
                    OutlinedButton(onClick = { obs.setScene(name) }, modifier = Modifier.fillMaxWidth()) { Text(name) }
                }
            }

            OutlinedButton(
                onClick = { obs.disconnect() },
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
            ) { Text("Se déconnecter") }
        }

        s.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    }
}
