package com.livebridge.vdo

import android.annotation.SuppressLint
import android.content.Context
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.net.Uri

/** Construit les liens VDO.Ninja (service public https://vdo.ninja, aucun code copié). */
object VdoLinks {
    private const val BASE = "https://vdo.ninja/"

    /** Lien ouvert dans l'app : le téléphone PUBLIE sa caméra/micro. */
    fun push(id: String, password: String, label: String, bitrateKbps: Int, quality: Int): String =
        buildString {
            append(BASE).append("?push=").append(Uri.encode(id.trim()))
            append("&webcam&autostart")
            append("&quality=").append(quality)
            if (bitrateKbps > 0) append("&bitrate=").append(bitrateKbps)
            if (label.isNotBlank()) append("&label=").append(Uri.encode(label.trim()))
            if (password.isNotBlank()) append("&password=").append(Uri.encode(password))
        }

    /** Lien à coller dans OBS (Source > Navigateur) : reçoit le flux du téléphone. */
    fun view(id: String, password: String): String =
        buildString {
            append(BASE).append("?view=").append(Uri.encode(id.trim()))
            append("&cleanoutput")
            if (password.isNotBlank()) append("&password=").append(Uri.encode(password))
        }
}

private fun isVdoHost(host: String?) = host == "vdo.ninja" || host?.endsWith(".vdo.ninja") == true

/** WebView configurée pour WebRTC (caméra + micro), limitée au domaine vdo.ninja. */
@SuppressLint("SetJavaScriptEnabled")
fun newVdoWebView(context: Context): WebView = WebView(context).apply {
    settings.javaScriptEnabled = true
    settings.domStorageEnabled = true
    settings.mediaPlaybackRequiresUserGesture = false

    webViewClient = object : WebViewClient() {
        // Bloque toute navigation hors de vdo.ninja.
        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
            !isVdoHost(request.url.host)
    }
    webChromeClient = object : WebChromeClient() {
        override fun onPermissionRequest(request: PermissionRequest) {
            // Les permissions Android (caméra/micro) sont déjà accordées à l'app ;
            // on ne les transmet qu'au site VDO.Ninja.
            if (isVdoHost(request.origin.host)) request.grant(request.resources) else request.deny()
        }
    }
}
