package com.livebridge.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.livebridge.Prefs
import com.livebridge.rememberPref
import com.livebridge.rtmp.Quality
import com.livebridge.rtmp.RtmpUi
import com.livebridge.rtmp.StreamController

val PLATFORMS = listOf("YouTube", "Twitch", "Facebook", "Autre")

private const val YOUTUBE_HELP =
    "Clé : YouTube Studio → Créer → Passer en direct → onglet Diffusion → « Clé de stream ». " +
        "La diffusion doit être activée sur la chaîne (jusqu'à 24 h après vérification)."

/** URL complète d'envoi, d'après la destination choisie. Vide si incomplète. */
fun rtmpUrl(platform: String, ytTls: String, customBase: String, key: String): String {
    val base = when (platform) {
        "YouTube" ->
            if (ytTls == "1") "rtmps://a.rtmps.youtube.com:443/live2" else "rtmp://a.rtmp.youtube.com/live2"
        "Twitch" -> "rtmp://live.twitch.tv/app"
        "Facebook" -> "rtmps://live-api-s.facebook.com:443/rtmp"
        else -> customBase.trim()
    }
    return when {
        base.isBlank() -> ""
        key.isBlank() -> base
        else -> base.trimEnd('/') + "/" + key.trim().trimStart('/')
    }
}

/**
 * Écran « Configuration du direct » (avant de démarrer) : titre, catégorie, destination,
 * micro/réduction de bruit/caméra, aperçu, gros bouton de démarrage. Inspiré de la maquette
 * « OBS Mobile » fournie.
 */
@Composable
fun SetupScreen(
    controller: StreamController,
    store: com.livebridge.studio.StudioStore,
    prefs: Prefs,
    blockedByOther: Boolean,
    onStart: () -> Unit,
    onOpenElements: () -> Unit
) {
    val ui by controller.ui.collectAsState()
    val studio by store.state.collectAsState()

    val title = rememberPref(prefs, "stream_title", "Live !")
    val category = rememberPref(prefs, "stream_category", "Discussion & Voyage")
    val platform = rememberPref(prefs, "rtmp_platform", "YouTube")
    val ytTls = rememberPref(prefs, "rtmp_yt_tls", "1")
    val customBase = rememberPref(prefs, "rtmp_custom_base")
    val key = rememberPref(prefs, "rtmp_key")

    var showAdvanced by remember { mutableStateOf(false) }

    val url = rtmpUrl(platform.value, ytTls.value, customBase.value, key.value)
    val canStart = url.isNotBlank() && !blockedByOther

    Column(
        Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Prêt à diffuser", style = MaterialTheme.typography.titleLarge)

        Field(title, "Titre")
        Field(category, "Catégorie")

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PLATFORMS.forEach { name ->
                FilterChip(
                    selected = platform.value == name,
                    onClick = { platform.value = name },
                    label = { Text(name) }
                )
            }
        }
        if (platform.value == "YouTube") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = ytTls.value == "1", onClick = { ytTls.value = "1" }, label = { Text("RTMPS") })
                FilterChip(selected = ytTls.value != "1", onClick = { ytTls.value = "0" }, label = { Text("RTMP") })
            }
        }
        if (platform.value == "Autre") {
            Field(customBase, "URL du serveur (rtmp://, rtmps://, srt://…)")
        }
        Field(key, if (platform.value == "Autre") "Nom du flux / clé (facultatif)" else "Clé de stream", secret = true)
        if (platform.value == "YouTube") Text(YOUTUBE_HELP, style = MaterialTheme.typography.bodySmall)

        PreviewCanvas(controller, store, studio.current, editable = false, modifier = Modifier.fillMaxWidth())

        Text("Paramètres", style = MaterialTheme.typography.titleMedium)
        ToggleRow("Activer le micro", !ui.micMuted) { controller.setMicMuted(!it) }
        ToggleRow("Réduire le bruit", ui.noiseReduction, enabled = !(ui.streaming || ui.connecting)) {
            controller.setNoiseReduction(it)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Caméra", Modifier.weight(1f))
            OutlinedButton(onClick = { controller.switchCamera() }) { Text("Avant / arrière") }
        }

        TextButton(onClick = onOpenElements) { Text("Modifier les éléments (logo, texte…) →") }
        TextButton(onClick = { showAdvanced = !showAdvanced }) {
            Text(if (showAdvanced) "Masquer les réglages avancés" else "Réglages avancés (qualité, journal)")
        }
        if (showAdvanced) AdvancedSettings(controller, ui)

        ui.message?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        if (blockedByOther) {
            Text("Arrête d'abord l'autre flux : la caméra ne peut servir qu'à un direct à la fois.",
                color = MaterialTheme.colorScheme.error)
        }

        Button(
            onClick = onStart,
            enabled = canStart,
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text("Commencer le direct") }
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}

@Composable
private fun AdvancedSettings(controller: StreamController, ui: RtmpUi) {
    val live = ui.streaming || ui.connecting || ui.recording
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text("Qualité", style = MaterialTheme.typography.labelLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Quality.entries.forEach { q ->
                FilterChip(
                    selected = ui.quality == q,
                    onClick = { controller.setQuality(q) },
                    enabled = !live,
                    label = { Text(q.label) }
                )
            }
        }
        ui.lastRecordPath?.let { Text("Dernier enregistrement : $it", style = MaterialTheme.typography.bodySmall) }
    }
}
