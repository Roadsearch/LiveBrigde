package com.livebridge.ui

import android.content.res.Configuration
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.dp
import com.livebridge.Prefs
import com.livebridge.rememberPref
import com.livebridge.rtmp.Quality
import com.livebridge.rtmp.RtmpUi
import com.livebridge.rtmp.StreamController
import com.livebridge.studio.StudioStore

val PLATFORMS = listOf("YouTube", "Twitch", "Facebook", "Autre")
private const val YOUTUBE_HELP = "YouTube Studio → Créer → Passer en direct → Diffusion → Clé de stream."

fun rtmpUrl(platform: String, ytTls: String, customBase: String, key: String): String {
    val base = when (platform) {
        "YouTube" -> if (ytTls == "1") "rtmps://a.rtmps.youtube.com:443/live2" else "rtmp://a.rtmp.youtube.com/live2"
        "Twitch" -> "rtmp://live.twitch.tv/app"
        "Facebook" -> "rtmps://live-api-s.facebook.com:443/rtmp"
        else -> customBase.trim()
    }
    return when {
        base.isBlank() -> ""
        key.isBlank() -> base
        else -> base.trimEnd('/') + "/" + key.trim().trimStart('/')
    }
}

@Composable
fun SetupScreen(
    controller: StreamController,
    store: StudioStore,
    prefs: Prefs,
    blockedByOther: Boolean,
    onStart: () -> Unit,
    onOpenElements: () -> Unit
) {
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val ui by controller.ui.collectAsState()
    val studio by store.state.collectAsState()
    val title = rememberPref(prefs, "stream_title", "Mon direct")
    val category = rememberPref(prefs, "stream_category", "Discussion & Voyage")
    val platform = rememberPref(prefs, "rtmp_platform", "YouTube")
    val ytTls = rememberPref(prefs, "rtmp_yt_tls", "1")
    val customBase = rememberPref(prefs, "rtmp_custom_base")
    val key = rememberPref(prefs, "rtmp_key")
    var showAdvanced by remember { mutableStateOf(false) }
    val url = rtmpUrl(platform.value, ytTls.value, customBase.value, key.value)
    val canStart = url.isNotBlank() && !blockedByOther && !ui.connecting && !ui.streaming

    val preview = @Composable { modifier: Modifier ->
        SettingCard("Aperçu", "Scène actuelle · ${studio.current.name}", modifier) {
            PreviewCanvas(controller, store, studio.current, editable = false, modifier = Modifier.fillMaxWidth())
        }
    }

    val form = @Composable {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            SettingCard("Votre direct", "Ces informations seront enregistrées pour la prochaine session.") {
                Field(title, "Titre du direct")
                Field(category, "Catégorie")
            }

            SettingCard("Destination", "Choisissez où envoyer votre diffusion.") {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PLATFORMS.forEach { name ->
                        FilterChip(selected = platform.value == name, onClick = { platform.value = name }, label = { Text(name) })
                    }
                }
                if (platform.value == "YouTube") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = ytTls.value == "1", onClick = { ytTls.value = "1" }, label = { Text("RTMPS") })
                        FilterChip(selected = ytTls.value != "1", onClick = { ytTls.value = "0" }, label = { Text("RTMP") })
                    }
                    Text(YOUTUBE_HELP, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (platform.value == "Autre") Field(customBase, "URL du serveur (rtmp://, rtmps://, srt://…)")
                Field(key, if (platform.value == "Autre") "Clé / nom du flux (facultatif)" else "Clé de stream", secret = true)
            }

            SettingCard("Vidéo et audio", "Préparez vos sources avant de démarrer.") {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Caméra", style = MaterialTheme.typography.labelLarge)
                        Text("Changer la caméra utilisée", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    OutlinedButton(onClick = { controller.switchCamera() }) { Text("Avant / arrière") }
                }
                ToggleRow("Microphone", !ui.micMuted) { controller.setMicMuted(!it) }
                ToggleRow("Réduction du bruit", ui.noiseReduction, enabled = !ui.streaming && !ui.connecting) { controller.setNoiseReduction(it) }
            }

            SettingCard("Scène", "Ajoutez un logo ou un texte sans quitter la préparation.") {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(studio.current.name, style = MaterialTheme.typography.labelLarge)
                        Text("Caméra + ${studio.current.sources.count { it.type != com.livebridge.studio.SourceType.CAMERA }} élément(s)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    OutlinedButton(onClick = onOpenElements) { Text("Modifier") }
                }
            }

            TextButton(onClick = { showAdvanced = !showAdvanced }) {
                IconTextButtonLabel(showAdvanced, "Réglages avancés")
            }
            AnimatedVisibility(showAdvanced, enter = fadeIn(), exit = fadeOut()) { AdvancedSettings(controller, ui) }

            AnimatedVisibility(ui.message != null, enter = fadeIn(), exit = fadeOut()) { ui.message?.let { AppBanner(it, BannerKind.ERROR) } }
            if (blockedByOther) AppBanner("Un autre direct utilise déjà la caméra.", BannerKind.WARNING)

            Button(
                onClick = onStart,
                enabled = canStart,
                colors = ButtonDefaults.buttonColors(containerColor = LiveRed, disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = MaterialTheme.shapes.medium
            ) {
                Text(if (ui.connecting) "Connexion…" else "Commencer le direct", style = MaterialTheme.typography.labelLarge)
            }
        }
    }

    if (landscape) {
        Row(Modifier.fillMaxSize().padding(Spacing.l), horizontalArrangement = Arrangement.spacedBy(Spacing.l)) {
            Column(Modifier.weight(1.15f).fillMaxHeight()) {
                StepHeader(1, 3, "Configurer", "Préparez votre diffusion")
                preview(Modifier.fillMaxWidth())
            }
            Column(Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState())) { form() }
        }
    } else {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(Spacing.l), verticalArrangement = Arrangement.spacedBy(Spacing.m)) {
            StepHeader(1, 3, "Configurer", "Préparez votre diffusion")
            form()
            Spacer(Modifier.height(Spacing.s))
            preview(Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun IconTextButtonLabel(expanded: Boolean, label: String) {
    androidx.compose.material3.Icon(Icons.Filled.Tune, contentDescription = null, modifier = Modifier.padding(end = 6.dp))
    Text(if (expanded) "Masquer $label" else label)
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().height(52.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        androidx.compose.material3.Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}

@Composable
private fun AdvancedSettings(controller: StreamController, ui: RtmpUi) {
    val live = ui.streaming || ui.connecting || ui.recording
    Column(
        Modifier.fillMaxWidth().clip(MaterialTheme.shapes.medium).padding(Spacing.m),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("Qualité vidéo", style = MaterialTheme.typography.labelLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Quality.entries.forEach { q ->
                FilterChip(selected = ui.quality == q, onClick = { controller.setQuality(q) }, enabled = !live, label = { Text(q.label) })
            }
        }
        ui.lastRecordPath?.let { Text("Dernier enregistrement : $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}
