package com.livebridge.ui

import android.content.res.Configuration
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import com.livebridge.Prefs
import com.livebridge.rememberPref
import com.livebridge.rtmp.StreamController
import com.livebridge.studio.StudioStore

private enum class Phase { SETUP, ELEMENTS }
private enum class ScreenKey { SETUP, ELEMENTS, LIVE }

/**
 * Écran unique de l'app : Configuration / Éléments avant le direct, puis bascule automatique
 * sur le tableau de bord En direct dès que le flux démarre. Chaque écran a une mise en page
 * dédiée en portrait et en paysage (voir SetupScreen, ElementsScreen, LiveDashboardScreen).
 * Le passage d'un écran à l'autre est animé en fondu pour éviter le changement brutal.
 */
@Composable
fun StudioScreen(controller: StreamController, store: StudioStore, prefs: Prefs) {
    CameraMicGate {
        val ui by controller.ui.collectAsState()
        val studio by store.state.collectAsState()
        var phase by remember { mutableStateOf(Phase.SETUP) }

        // Rotation du téléphone -> l'encodeur bascule portrait/paysage (verrouillé pendant un direct,
        // voir StreamController.setOrientation).
        val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
        LaunchedEffect(landscape) { controller.setOrientation(landscape) }

        val platform = rememberPref(prefs, "rtmp_platform", "YouTube")
        val ytTls = rememberPref(prefs, "rtmp_yt_tls", "1")
        val customBase = rememberPref(prefs, "rtmp_custom_base")
        val key = rememberPref(prefs, "rtmp_key")
        val url = rtmpUrl(platform.value, ytTls.value, customBase.value, key.value)

        val live = ui.streaming || ui.connecting
        val screen = when {
            live -> ScreenKey.LIVE
            phase == Phase.ELEMENTS -> ScreenKey.ELEMENTS
            else -> ScreenKey.SETUP
        }

        Box(Modifier.fillMaxSize()) {
            Crossfade(targetState = screen, animationSpec = tween(220), label = "screen") { key2 ->
                when (key2) {
                    ScreenKey.LIVE -> LiveDashboardScreen(
                        controller, store, studio.current, ui,
                        onStop = { controller.stop(); phase = Phase.SETUP }
                    )
                    ScreenKey.ELEMENTS -> ElementsScreen(controller, store) { phase = Phase.SETUP }
                    ScreenKey.SETUP -> SetupScreen(
                        controller, store, prefs,
                        blockedByOther = false,
                        onStart = { controller.start(url) },
                        onOpenElements = { phase = Phase.ELEMENTS }
                    )
                }
            }
        }
    }
}
