package com.livebridge.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.livebridge.Prefs
import com.livebridge.rememberPref
import com.livebridge.rtmp.StreamController
import com.livebridge.studio.StudioStore

private enum class Phase { SETUP, ELEMENTS }

/**
 * Écran unique de l'app : Configuration / Éléments avant le direct, puis bascule automatique
 * sur le tableau de bord En direct dès que le flux démarre.
 */
@Composable
fun StudioScreen(controller: StreamController, store: StudioStore, prefs: Prefs) {
    CameraMicGate {
        val ui by controller.ui.collectAsState()
        val studio by store.state.collectAsState()
        var phase by remember { mutableStateOf(Phase.SETUP) }

        val platform = rememberPref(prefs, "rtmp_platform", "YouTube")
        val ytTls = rememberPref(prefs, "rtmp_yt_tls", "1")
        val customBase = rememberPref(prefs, "rtmp_custom_base")
        val key = rememberPref(prefs, "rtmp_key")
        val url = rtmpUrl(platform.value, ytTls.value, customBase.value, key.value)

        val live = ui.streaming || ui.connecting

        Box(Modifier.fillMaxSize()) {
            when {
                live -> LiveDashboardScreen(
                    controller, store, studio.current, ui,
                    onStop = { controller.stop(); phase = Phase.SETUP }
                )
                phase == Phase.ELEMENTS -> ElementsScreen(controller, store) { phase = Phase.SETUP }
                else -> SetupScreen(
                    controller, store, prefs,
                    blockedByOther = false,
                    onStart = { controller.start(url) },
                    onOpenElements = { phase = Phase.ELEMENTS }
                )
            }
        }
    }
}
