package com.livebridge.ui

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.view.SurfaceHolder
import android.view.SurfaceView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.livebridge.Prefs
import com.livebridge.rememberPref
import com.livebridge.rtmp.RtmpUi
import com.livebridge.rtmp.StreamController
import com.livebridge.studio.StudioStore
import kotlinx.coroutines.delay

/**
 * Écran principal façon OBS Studio, pensé mobile :
 * - portrait : aperçu en haut, onglets Scènes / Sources / Audio, barre d'action toujours visible ;
 * - paysage : aperçu à gauche, Scènes + Sources côte à côte et mélangeur audio à droite.
 */
@Composable
fun StudioScreen(controller: StreamController, store: StudioStore, prefs: Prefs, blockedByVdo: Boolean) {
    CameraMicGate { StudioContent(controller, store, prefs, blockedByVdo) }
}

@Composable
private fun StudioContent(
    controller: StreamController,
    store: StudioStore,
    prefs: Prefs,
    blockedByVdo: Boolean
) {
    val ui by controller.ui.collectAsState()
    val logs by controller.logs.collectAsState()
    val studio by store.state.collectAsState()
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    val platform = rememberPref(prefs, "rtmp_platform", "YouTube")
    val ytTls = rememberPref(prefs, "rtmp_yt_tls", "1")
    val customBase = rememberPref(prefs, "rtmp_custom_base")
    val key = rememberPref(prefs, "rtmp_key")

    var showSettings by remember { mutableStateOf(false) }
    var tab by rememberSaveable { mutableStateOf(0) }

    val url = rtmpUrl(platform.value, ytTls.value, customBase.value, key.value)
    val live = ui.streaming || ui.connecting
    val canStart = url.isNotBlank() && !blockedByVdo

    val onStartStop = { if (live) controller.stop() else controller.start(url) }

    if (landscape) {
        Row(
            Modifier.fillMaxSize().padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Column(
                Modifier.weight(1.35f).fillMaxHeight(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                PreviewBox(controller, ui, Modifier.fillMaxWidth())
                Notices(ui, blockedByVdo)
                Spacer(Modifier.weight(1f))
                ActionBar(ui, canStart, onStartStop, { controller.toggleRecord() }, { showSettings = true })
            }
            Column(
                Modifier.weight(1f).fillMaxHeight(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ScenesPanel(store, studio, Modifier.weight(1f).fillMaxHeight())
                    SourcesPanel(store, studio, controller, Modifier.weight(1.25f).fillMaxHeight())
                }
                MixerPanel(controller, ui, Modifier.fillMaxWidth())
            }
        }
    } else {
        Column(
            Modifier.fillMaxSize().padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            PreviewBox(controller, ui, Modifier.fillMaxWidth())
            Notices(ui, blockedByVdo)
            TabRow(selectedTabIndex = tab) {
                listOf("Scènes", "Sources", "Audio").forEachIndexed { i, title ->
                    Tab(selected = tab == i, onClick = { tab = i }, text = { Text(title) })
                }
            }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (tab) {
                    0 -> ScenesPanel(store, studio, Modifier.fillMaxSize())
                    1 -> SourcesPanel(store, studio, controller, Modifier.fillMaxSize())
                    else -> MixerPanel(controller, ui, Modifier.fillMaxWidth())
                }
            }
            ActionBar(ui, canStart, onStartStop, { controller.toggleRecord() }, { showSettings = true })
        }
    }

    if (showSettings) {
        SettingsDialog(
            controller = controller, ui = ui, logs = logs,
            platform = platform, ytTls = ytTls, customBase = customBase, key = key,
            onDismiss = { showSettings = false }
        )
    }
}

// ---------------------------------------------------------------------------------------------
// Aperçu + barre d'état
// ---------------------------------------------------------------------------------------------

@Composable
private fun PreviewBox(controller: StreamController, ui: RtmpUi, modifier: Modifier) {
    Box(modifier.aspectRatio(16f / 9f).clip(RoundedCornerShape(10.dp)).background(Color.Black)) {
        AndroidView(
            factory = { c ->
                val sv = SurfaceView(c)
                sv.holder.addCallback(object : SurfaceHolder.Callback {
                    override fun surfaceCreated(holder: SurfaceHolder) = controller.attachPreview(sv)
                    override fun surfaceChanged(holder: SurfaceHolder, f: Int, w: Int, h: Int) =
                        controller.onPreviewSize(w, h)
                    override fun surfaceDestroyed(holder: SurfaceHolder) = controller.detachPreview()
                })
                sv
            },
            modifier = Modifier.fillMaxSize()
        )
        StatusOverlay(ui, Modifier.align(Alignment.TopStart).fillMaxWidth())
    }
}

private data class SysInfo(val battery: Int, val tempC: Float, val net: String)

private fun readSys(ctx: Context): SysInfo {
    val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
    val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
    val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
    val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val caps = cm.getNetworkCapabilities(cm.activeNetwork)
    val net = when {
        caps == null -> "hors réseau"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
        else -> "réseau"
    }
    return SysInfo(if (level >= 0) level * 100 / scale else -1, temp, net)
}

private fun elapsed(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%02d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
}

@Composable
private fun StatusOverlay(ui: RtmpUi, modifier: Modifier) {
    val ctx = LocalContext.current
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    var sys by remember { mutableStateOf(readSys(ctx)) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            sys = readSys(ctx)
            delay(1000)
        }
    }

    val (label, color) = when {
        ui.streaming -> "● DIRECT ${elapsed(now - ui.liveSince)}" to Color(0xFFFF5252)
        ui.connecting -> "Connexion…" to Color(0xFFFFB300)
        else -> "HORS LIGNE" to Color(0xFFB0B8C8)
    }

    Row(
        modifier.background(Color(0x99000000)).padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(label, color = color, fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
        Text("${ui.fps} FPS", color = Color.White, fontSize = 11.sp, maxLines = 1)
        Text(
            if (ui.streaming) "${ui.bitrateKbps} kb/s" else ui.quality.label,
            color = Color.White, fontSize = 11.sp, maxLines = 1
        )
        if (ui.recording) Text("● REC", color = Color(0xFFFF5252), fontWeight = FontWeight.Bold, fontSize = 11.sp)
        Spacer(Modifier.weight(1f))
        val battery = if (sys.battery >= 0) "${sys.battery}%" else "--"
        Text(
            "$battery · ${sys.tempC.toInt()}°C · ${sys.net}",
            color = Color.White, fontSize = 11.sp, maxLines = 1
        )
    }
}

@Composable
private fun Notices(ui: RtmpUi, blockedByVdo: Boolean) {
    ui.message?.let {
        Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
    }
    if (blockedByVdo) {
        Text(
            "Arrête d'abord le live VDO.Ninja : la caméra ne peut servir qu'à un seul flux.",
            color = MaterialTheme.colorScheme.error,
            style = MaterialTheme.typography.bodySmall
        )
    }
}

// ---------------------------------------------------------------------------------------------
// Commandes
// ---------------------------------------------------------------------------------------------

@Composable
private fun ActionBar(
    ui: RtmpUi,
    canStart: Boolean,
    onStartStop: () -> Unit,
    onRecord: () -> Unit,
    onSettings: () -> Unit
) {
    val live = ui.streaming || ui.connecting
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Button(
            onClick = onStartStop,
            enabled = live || canStart,
            colors = ButtonDefaults.buttonColors(
                containerColor = if (live) LiveRed else MaterialTheme.colorScheme.primary
            ),
            contentPadding = PaddingValues(horizontal = 8.dp),
            modifier = Modifier.weight(2f).height(52.dp)
        ) { Text(if (live) "■ Arrêter le direct" else "● Démarrer le direct", maxLines = 1) }

        OutlinedButton(
            onClick = onRecord,
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = if (ui.recording) LiveRed else MaterialTheme.colorScheme.onSurface
            ),
            contentPadding = PaddingValues(horizontal = 8.dp),
            modifier = Modifier.weight(1f).height(52.dp)
        ) { Text(if (ui.recording) "■ REC" else "○ REC", maxLines = 1) }

        OutlinedButton(
            onClick = onSettings,
            contentPadding = PaddingValues(horizontal = 14.dp),
            modifier = Modifier.height(52.dp)
        ) { Text("⚙") }
    }
}
