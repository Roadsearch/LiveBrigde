package com.livebridge

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import com.livebridge.obs.ObsClient
import com.livebridge.rtmp.StreamController
import com.livebridge.ui.ObsScreen
import com.livebridge.ui.RtmpScreen
import com.livebridge.ui.VdoScreen
import com.livebridge.vdo.newVdoWebView

class MainActivity : ComponentActivity() {

    private val obs = ObsClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = Prefs(this)
        val rtmp = StreamController.get(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) {
                    LiveBridgeApp(prefs, rtmp, obs)
                }
            }
        }
    }

    override fun onDestroy() {
        if (isFinishing) obs.disconnect()
        super.onDestroy()
    }
}

@Composable
private fun LiveBridgeApp(prefs: Prefs, rtmp: StreamController, obs: ObsClient) {
    val ctx = LocalContext.current
    var tab by rememberSaveable { mutableStateOf(0) }
    var vdoLive by remember { mutableStateOf(false) }
    val rtmpUi by rtmp.ui.collectAsState()

    // La WebView VDO.Ninja vit ici pour survivre aux changements d'onglet pendant un envoi.
    val webView = remember { newVdoWebView(ctx) }
    DisposableEffect(Unit) { onDispose { webView.destroy() } }

    // Écran allumé pendant tout live.
    val view = LocalView.current
    val anyLive = rtmpUi.streaming || rtmpUi.connecting || vdoLive
    SideEffect { view.keepScreenOn = anyLive }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == 0, onClick = { tab = 0 },
                    icon = { Icon(Icons.Filled.PlayArrow, contentDescription = null) },
                    label = { Text("Live RTMP") }
                )
                NavigationBarItem(
                    selected = tab == 1, onClick = { tab = 1 },
                    icon = { Icon(Icons.Filled.Share, contentDescription = null) },
                    label = { Text("VDO.Ninja") }
                )
                NavigationBarItem(
                    selected = tab == 2, onClick = { tab = 2 },
                    icon = { Icon(Icons.Filled.Settings, contentDescription = null) },
                    label = { Text("OBS") }
                )
            }
        }
    ) { inner ->
        Box(Modifier.padding(inner).fillMaxSize()) {
            when (tab) {
                0 -> RtmpScreen(rtmp, prefs, blockedByVdo = vdoLive)
                1 -> VdoScreen(
                    webView, prefs, live = vdoLive,
                    blockedByRtmp = rtmpUi.streaming || rtmpUi.connecting,
                    onLive = { vdoLive = it }
                )
                else -> ObsScreen(obs, prefs)
            }
        }
    }
}
