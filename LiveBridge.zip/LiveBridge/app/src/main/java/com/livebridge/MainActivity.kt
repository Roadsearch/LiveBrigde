package com.livebridge

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalView
import com.livebridge.rtmp.StreamController
import com.livebridge.studio.StudioStore
import com.livebridge.ui.AppTypography
import com.livebridge.ui.AppShapes
import com.livebridge.ui.ObsColors
import com.livebridge.ui.StudioScreen

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = Prefs(this)
        val rtmp = StreamController.get(this)
        val store = StudioStore(this, prefs, rtmp)
        setContent {
            MaterialTheme(colorScheme = ObsColors, typography = AppTypography, shapes = AppShapes) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    val ui by rtmp.ui.collectAsState()
                    val view = LocalView.current
                    // Écran allumé pendant tout direct ou enregistrement.
                    SideEffect { view.keepScreenOn = ui.streaming || ui.connecting || ui.recording }
                    StudioScreen(rtmp, store, prefs)
                }
            }
        }
    }
}
