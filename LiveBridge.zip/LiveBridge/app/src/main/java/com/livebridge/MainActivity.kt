package com.livebridge

import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import com.livebridge.obs.ObsClient
import com.livebridge.rtmp.StreamController
import com.livebridge.studio.StudioStore
import com.livebridge.ui.ObsColors
import com.livebridge.ui.ObsScreen
import com.livebridge.ui.StudioScreen
import com.livebridge.ui.VdoScreen
import com.livebridge.vdo.newVdoWebView

class MainActivity : ComponentActivity() {

    private val obs = ObsClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = Prefs(this)
        val rtmp = StreamController.get(this)
        val store = StudioStore(this, prefs, rtmp)
        setContent {
            MaterialTheme(colorScheme = ObsColors) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    LiveBridgeApp(prefs, rtmp, store, obs)
                }
            }
        }
    }

    override fun onDestroy() {
        if (isFinishing) obs.disconnect()
        super.onDestroy()
    }
}

private data class NavTab(val label: String, val icon: ImageVector)

private val TABS = listOf(
    NavTab("Studio", Icons.Filled.PlayArrow),
    NavTab("VDO.Ninja", Icons.Filled.Share),
    NavTab("OBS", Icons.Filled.Settings)
)

@Composable
private fun LiveBridgeApp(prefs: Prefs, rtmp: StreamController, store: StudioStore, obs: ObsClient) {
    val ctx = LocalContext.current
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    var tab by rememberSaveable { mutableStateOf(0) }
    var vdoLive by remember { mutableStateOf(false) }
    val rtmpUi by rtmp.ui.collectAsState()

    // La WebView VDO.Ninja vit ici pour survivre aux changements d'onglet pendant un envoi.
    val webView = remember { newVdoWebView(ctx) }
    DisposableEffect(Unit) { onDispose { webView.destroy() } }

    // Écran allumé pendant tout live ou enregistrement.
    val view = LocalView.current
    val cameraBusy = rtmpUi.streaming || rtmpUi.connecting || rtmpUi.recording
    SideEffect { view.keepScreenOn = cameraBusy || vdoLive }

    val content: @Composable () -> Unit = {
        when (tab) {
            0 -> StudioScreen(rtmp, store, prefs, blockedByVdo = vdoLive)
            1 -> VdoScreen(
                webView, prefs, live = vdoLive,
                blockedByRtmp = cameraBusy,
                onLive = { vdoLive = it }
            )
            else -> ObsScreen(obs, prefs)
        }
    }

    if (landscape) {
        Row(Modifier.fillMaxSize().safeDrawingPadding()) {
            NavigationRail {
                TABS.forEachIndexed { i, t ->
                    NavigationRailItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Icon(t.icon, contentDescription = null) },
                        label = { Text(t.label) }
                    )
                }
            }
            Box(Modifier.weight(1f).fillMaxHeight()) { content() }
        }
    } else {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                NavigationBar {
                    TABS.forEachIndexed { i, t ->
                        NavigationBarItem(
                            selected = tab == i, onClick = { tab = i },
                            icon = { Icon(t.icon, contentDescription = null) },
                            label = { Text(t.label) }
                        )
                    }
                }
            }
        ) { inner ->
            Box(Modifier.padding(inner).fillMaxSize()) { content() }
        }
    }
}
