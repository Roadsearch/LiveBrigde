package com.livebridge.obs

import android.util.Base64
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

data class ObsState(
    val connecting: Boolean = false,
    val connected: Boolean = false,
    val error: String? = null,
    val scenes: List<String> = emptyList(),
    val currentScene: String? = null,
    val streaming: Boolean = false,
    val recording: Boolean = false
)

/**
 * Client du protocole obs-websocket v5 (intégré à OBS Studio 28+).
 * OBS : Outils > Paramètres du serveur WebSocket > Activer (port 4455 par défaut) + mot de passe.
 * Spécification publique : https://github.com/obsproject/obs-websocket/blob/master/docs/generated/protocol.md
 */
class ObsClient {

    private val _state = MutableStateFlow(ObsState())
    val state: StateFlow<ObsState> = _state.asStateFlow()

    private val http = OkHttpClient.Builder()
        .connectTimeout(6, TimeUnit.SECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    private var socket: WebSocket? = null
    private var password = ""
    private val pending = ConcurrentHashMap<String, (JSONObject) -> Unit>()

    // ---- Connexion -----------------------------------------------------------------------

    fun connect(host: String, port: Int, password: String) {
        disconnect()
        this.password = password
        _state.value = ObsState(connecting = true)
        val request = Request.Builder().url("ws://${host.trim()}:$port").build()
        socket = http.newWebSocket(request, listener)
    }

    fun disconnect() {
        socket?.close(1000, null)
        socket = null
        pending.clear()
        _state.value = ObsState()
    }

    // ---- Actions -------------------------------------------------------------------------

    fun startStream() = action("StartStream")
    fun stopStream() = action("StopStream")
    fun startRecord() = action("StartRecord")
    fun stopRecord() = action("StopRecord")

    fun setScene(name: String) =
        action("SetCurrentProgramScene", JSONObject().put("sceneName", name))

    private fun action(type: String, data: JSONObject? = null) {
        request(type, data) { d ->
            if (!ok(d)) {
                val comment = d.optJSONObject("requestStatus")?.optString("comment").orEmpty()
                _state.update { it.copy(error = "$type : ${comment.ifBlank { "refusé par OBS" }}") }
            }
        }
    }

    // ---- Protocole -----------------------------------------------------------------------

    private fun request(type: String, data: JSONObject? = null, callback: ((JSONObject) -> Unit)? = null) {
        val id = UUID.randomUUID().toString()
        if (callback != null) pending[id] = callback
        val d = JSONObject().put("requestType", type).put("requestId", id)
        if (data != null) d.put("requestData", data)
        socket?.send(JSONObject().put("op", 6).put("d", d).toString())
    }

    private fun ok(d: JSONObject) = d.optJSONObject("requestStatus")?.optBoolean("result") == true

    private fun sha256b64(s: String): String =
        Base64.encodeToString(MessageDigest.getInstance("SHA-256").digest(s.toByteArray()), Base64.NO_WRAP)

    /** op 0 (Hello) -> op 1 (Identify), avec l'authentification challenge/salt si un mot de passe est requis. */
    private fun identify(ws: WebSocket, hello: JSONObject) {
        val d = JSONObject().put("rpcVersion", 1)
        hello.optJSONObject("authentication")?.let { auth ->
            val secret = sha256b64(password + auth.getString("salt"))
            d.put("authentication", sha256b64(secret + auth.getString("challenge")))
        }
        ws.send(JSONObject().put("op", 1).put("d", d).toString())
    }

    private fun refreshAll() {
        refreshScenes()
        request("GetStreamStatus") { d ->
            val on = d.optJSONObject("responseData")?.optBoolean("outputActive") == true
            _state.update { it.copy(streaming = on) }
        }
        request("GetRecordStatus") { d ->
            val on = d.optJSONObject("responseData")?.optBoolean("outputActive") == true
            _state.update { it.copy(recording = on) }
        }
    }

    private fun refreshScenes() = request("GetSceneList") { d ->
        val r = d.optJSONObject("responseData") ?: return@request
        val arr = r.optJSONArray("scenes")
        val scenes = buildList {
            if (arr != null) for (i in 0 until arr.length()) {
                val s = arr.getJSONObject(i)
                add(s.optInt("sceneIndex") to s.optString("sceneName"))
            }
        }.sortedByDescending { it.first }.map { it.second }   // OBS les renvoie en ordre inverse
        _state.update { it.copy(scenes = scenes, currentScene = r.optString("currentProgramSceneName")) }
    }

    private fun handleEvent(d: JSONObject) {
        val data = d.optJSONObject("eventData") ?: JSONObject()
        when (d.optString("eventType")) {
            "CurrentProgramSceneChanged" ->
                _state.update { it.copy(currentScene = data.optString("sceneName")) }
            "SceneListChanged" -> refreshScenes()
            "StreamStateChanged" ->
                _state.update { it.copy(streaming = data.optBoolean("outputActive")) }
            "RecordStateChanged" ->
                _state.update { it.copy(recording = data.optBoolean("outputActive")) }
        }
    }

    // ---- WebSocket -----------------------------------------------------------------------

    private val listener = object : WebSocketListener() {
        override fun onMessage(webSocket: WebSocket, text: String) {
            if (webSocket !== socket) return
            val msg = runCatching { JSONObject(text) }.getOrNull() ?: return
            val d = msg.optJSONObject("d") ?: JSONObject()
            when (msg.optInt("op")) {
                0 -> identify(webSocket, d)
                2 -> {
                    _state.update { it.copy(connected = true, connecting = false, error = null) }
                    refreshAll()
                }
                5 -> handleEvent(d)
                7 -> pending.remove(d.optString("requestId"))?.invoke(d)
            }
        }

        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            if (webSocket !== socket) return
            val error = if (code == 4009) "Mot de passe OBS incorrect." else null
            socket = null
            _state.value = ObsState(error = error)
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            if (webSocket !== socket) return
            socket = null
            _state.value = ObsState(
                error = "Connexion impossible (${t.message ?: "erreur réseau"}). " +
                    "Vérifie l'IP, le port, et que le téléphone est sur le même Wi-Fi."
            )
        }
    }
}
