package com.livebridge.ui

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.livebridge.rtmp.RtmpUi
import com.livebridge.rtmp.StreamController
import com.livebridge.studio.Scene
import com.livebridge.studio.StudioStore
import kotlinx.coroutines.delay

/**
 * Écran « En direct » : tableau de bord plein écran avec l'aperçu en fond, les statistiques et
 * des raccourcis rapides, comme sur la maquette. L'aperçu est en lecture seule (pas de glisser)
 * pour éviter de bouger un élément par erreur pendant le direct.
 */
@Composable
fun LiveDashboardScreen(
    controller: StreamController,
    store: StudioStore,
    scene: Scene,
    ui: RtmpUi,
    onStop: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Box {
            PreviewCanvas(controller, store, scene, editable = false, modifier = Modifier.fillMaxWidth())
            LiveBadge(ui, Modifier.align(Alignment.TopStart).padding(10.dp))
        }

        StatsGrid(ui)

        Text("Raccourcis", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ShortcutButton("🎤", if (ui.micMuted) "Activer le micro" else "Couper le micro", Modifier.weight(1f)) {
                controller.setMicMuted(!ui.micMuted)
            }
            ShortcutButton("🔄", "Changer de caméra", Modifier.weight(1f)) { controller.switchCamera() }
            ShortcutButton(
                if (ui.recording) "⏺" else "○",
                if (ui.recording) "Arrêter l'enreg." else "Enregistrer",
                Modifier.weight(1f)
            ) { controller.toggleRecord() }
        }

        ui.message?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Spacer(Modifier.weight(1f))

        Button(
            onClick = onStop,
            colors = ButtonDefaults.buttonColors(containerColor = LiveRed),
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text("Finir le direct") }
    }
}

@Composable
private fun LiveBadge(ui: RtmpUi, modifier: Modifier) {
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(1000) } }
    val (label, color) = when {
        ui.streaming -> "● DIRECT · ${elapsed(now - ui.liveSince)}" to Color(0xFFFF5252)
        ui.connecting -> "Connexion…" to Color(0xFFFFB300)
        else -> "Hors ligne" to Color(0xFFB0B8C8)
    }
    Row(
        modifier
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0x99000000))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(label, color = color, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }
}

private fun elapsed(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%02d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
}

private data class SysInfo(val battery: Int, val tempC: Float, val net: String)

private fun readSys(ctx: Context): SysInfo {
    val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
    val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
    val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
    val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val caps = cm.getNetworkCapabilities(cm.activeNetwork)
    val net = when {
        caps == null -> "hors réseau"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile"
        else -> "réseau"
    }
    return SysInfo(if (level >= 0) level * 100 / scale else -1, temp, net)
}

@Composable
private fun StatsGrid(ui: RtmpUi) {
    val ctx = LocalContext.current
    var sys by remember { mutableStateOf(readSys(ctx)) }
    LaunchedEffect(Unit) { while (true) { sys = readSys(ctx); delay(2000) } }

    val battery = if (sys.battery >= 0) "${sys.battery}%" else "--"
    val items = listOf(
        "Débit" to if (ui.streaming) "${ui.bitrateKbps} kb/s" else "--",
        "Qualité" to ui.quality.label,
        "Réseau" to sys.net,
        "Batterie" to "$battery · ${sys.tempC.toInt()}°C"
    )
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEach { (label, value) ->
            Column(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(8.dp)
            ) {
                Text(label, style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(value, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun ShortcutButton(icon: String, label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, modifier = modifier.height(64.dp)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(icon, fontSize = 18.sp)
            Text(label, style = MaterialTheme.typography.labelSmall, maxLines = 1)
        }
    }
}
