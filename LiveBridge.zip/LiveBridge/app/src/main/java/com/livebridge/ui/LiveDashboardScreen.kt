package com.livebridge.ui

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.livebridge.rtmp.RtmpUi
import com.livebridge.rtmp.StreamController
import com.livebridge.studio.Scene
import com.livebridge.studio.StudioStore
import kotlinx.coroutines.delay

@Composable
fun LiveDashboardScreen(controller: StreamController, store: StudioStore, scene: Scene, ui: RtmpUi, onStop: () -> Unit) {
    val landscape = LocalConfiguration.current.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
    var confirmStop by remember { mutableStateOf(false) }

    val preview: @Composable () -> Unit = {
        Box(Modifier.fillMaxWidth()) {
            PreviewCanvas(controller, store, scene, editable = false, modifier = Modifier.fillMaxWidth(), loading = ui.connecting)
            LiveBadge(ui, Modifier.align(Alignment.TopStart).padding(12.dp))
        }
    }

    val controls: @Composable () -> Unit = {
        SettingCard("Commandes rapides", "Les commandes restent accessibles pendant le direct.") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QuickControl(if (ui.micMuted) Icons.Filled.MicOff else Icons.Filled.Mic, if (ui.micMuted) "Micro coupé" else "Micro", !ui.micMuted) {
                    controller.setMicMuted(!ui.micMuted)
                }
                QuickControl(Icons.Filled.CameraAlt, "Caméra", true) { controller.switchCamera() }
                QuickControl(if (ui.recording) Icons.Filled.Stop else Icons.Filled.Stop, if (ui.recording) "Arrêter" else "Enregistrer", ui.recording) { controller.toggleRecord() }
                QuickControl(Icons.Filled.Refresh, "Resync", false) { controller.resync() }
            }
        }
        AnimatedVisibility(ui.message != null, enter = fadeIn(), exit = fadeOut()) { ui.message?.let { AppBanner(it, BannerKind.ERROR) } }
        Button(
            onClick = { confirmStop = true },
            colors = ButtonDefaults.buttonColors(containerColor = LiveRed),
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = MaterialTheme.shapes.medium
        ) {
            Icon(Icons.Filled.Stop, contentDescription = null)
            Text("Terminer le direct", Modifier.padding(start = 8.dp))
        }
    }

    if (landscape) {
        Row(Modifier.fillMaxSize().padding(Spacing.l), horizontalArrangement = Arrangement.spacedBy(Spacing.l)) {
            Column(Modifier.weight(1.35f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(Spacing.m)) {
                LiveHeader(ui)
                preview()
            }
            Column(Modifier.weight(.9f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(Spacing.m)) {
                StatsGrid(ui)
                controls()
                Spacer(Modifier.weight(1f))
                Text("La scène est verrouillée pendant le direct pour éviter les déplacements accidentels.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    } else {
        Column(Modifier.fillMaxSize().padding(Spacing.l), verticalArrangement = Arrangement.spacedBy(Spacing.m)) {
            LiveHeader(ui)
            preview()
            StatsGrid(ui)
            controls()
            Spacer(Modifier.weight(1f))
            Text("Les éléments sont protégés pendant le direct.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }

    if (confirmStop) {
        AlertDialog(
            onDismissRequest = { confirmStop = false },
            title = { Text("Terminer le direct ?") },
            text = { Text("La diffusion sera arrêtée pour tous les spectateurs.") },
            confirmButton = { TextButton(onClick = { confirmStop = false; onStop() }) { Text("Terminer", color = LiveRed) } },
            dismissButton = { TextButton(onClick = { confirmStop = false }) { Text("Continuer") } }
        )
    }
}

@Composable
private fun LiveHeader(ui: RtmpUi) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("En direct", style = MaterialTheme.typography.headlineSmall)
            Text(if (ui.connecting) "Connexion au serveur…" else "Votre diffusion est active", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        LiveBadge(ui)
    }
}

@Composable
private fun LiveBadge(ui: RtmpUi, modifier: Modifier = Modifier) {
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(ui.streaming, ui.connecting) { while (true) { now = System.currentTimeMillis(); delay(1000) } }
    val pulse = rememberInfiniteTransition(label = "livePulse")
    val alpha by pulse.animateFloat(1f, .35f, infiniteRepeatable(tween(650), RepeatMode.Reverse), label = "dot")
    val active = ui.streaming || ui.connecting
    val label = when { ui.streaming -> "LIVE · ${elapsed(now - ui.liveSince)}"; ui.connecting -> "CONNEXION"; else -> "HORS LIGNE" }
    Row(
        modifier.clip(MaterialTheme.shapes.small).background(if (active) LiveRed.copy(alpha = .15f) else MaterialTheme.colorScheme.surfaceVariant).padding(horizontal = 10.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(8.dp).background(if (active) LiveRed.copy(alpha = alpha) else MaterialTheme.colorScheme.onSurfaceVariant, CircleShape))
        Text(label, Modifier.padding(start = 7.dp), style = MaterialTheme.typography.labelMedium, color = if (active) LiveRed else MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
    }
}

private fun elapsed(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%02d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
}

private data class SysInfo(val battery: Int, val tempC: Float, val net: String)
private fun readSys(ctx: Context): SysInfo {
    val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
    val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
    val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
    val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val caps = cm.getNetworkCapabilities(cm.activeNetwork)
    val net = when { caps == null -> "Hors réseau"; caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi‑Fi"; caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile"; else -> "Réseau" }
    return SysInfo(if (level >= 0) level * 100 / scale else -1, temp, net)
}

@Composable
private fun StatsGrid(ui: RtmpUi) {
    val ctx = LocalContext.current
    var sys by remember { mutableStateOf(readSys(ctx)) }
    LaunchedEffect(Unit) { while (true) { sys = readSys(ctx); delay(2000) } }
    val items = listOf(
        "Débit" to if (ui.streaming) "${ui.bitrateKbps} kb/s" else "—",
        "Qualité" to ui.quality.label,
        "Réseau" to sys.net,
        "Batterie" to if (sys.battery >= 0) "${sys.battery}% · ${sys.tempC.toInt()}°C" else "—"
    )
    LazyVerticalGrid(columns = GridCells.Fixed(2), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth().height(112.dp)) {
        items(items) { (label, value) ->
            Column(Modifier.clip(MaterialTheme.shapes.small).background(MaterialTheme.colorScheme.surfaceVariant).padding(10.dp)) {
                Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(value, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun QuickControl(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, active: Boolean, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, modifier = Modifier.weight(1f).height(68.dp)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, contentDescription = label, tint = if (active) SemanticColors.success else MaterialTheme.colorScheme.onSurfaceVariant)
            Text(label, style = MaterialTheme.typography.labelSmall, maxLines = 1)
        }
    }
}
