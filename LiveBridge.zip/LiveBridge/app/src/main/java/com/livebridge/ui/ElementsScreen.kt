package com.livebridge.ui

import android.content.res.Configuration
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.livebridge.rtmp.StreamController
import com.livebridge.studio.Source
import com.livebridge.studio.SourceType
import com.livebridge.studio.StudioStore

/**
 * Écran « Édition des éléments » : aperçu tactile plein cadre (glisser / pincer) + calque des
 * sources en dessous, comme sur la maquette. Un doigt bouge la source sélectionnée ; deux doigts
 * la redimensionnent.
 */
@Composable
fun ElementsScreen(controller: StreamController, store: StudioStore, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val studio by store.state.collectAsState()
    var addMenu by remember { mutableStateOf(false) }
    var editingText by remember { mutableStateOf<String?>(null) }
    var imageTarget by remember { mutableStateOf<String?>(null) }   // "" = nouvelle image, sinon id à remplacer
    var renaming by remember { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        val target = imageTarget
        imageTarget = null
        if (uri != null && target != null) {
            val bmp = decodeLogo(ctx, uri, 1024)
            if (bmp != null) {
                if (target.isEmpty()) store.addImage("Image", bmp) else store.replaceImage(target, bmp)
            }
        }
    }
    fun pickImage(target: String) {
        imageTarget = target
        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    val header = @Composable {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Éléments", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            TextButton(onClick = onDone) { Text("Terminé") }
        }
    }
    val hint = @Composable {
        Text(
            "Touche une source pour la sélectionner, glisse pour la déplacer, pince pour la redimensionner.",
            style = MaterialTheme.typography.bodySmall
        )
    }
    val layersHeader = @Composable {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Calques (${studio.current.name})", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            Box {
                IconButton(onClick = { addMenu = true }) { Icon(Icons.Filled.Add, contentDescription = "Ajouter") }
                DropdownMenu(expanded = addMenu, onDismissRequest = { addMenu = false }) {
                    DropdownMenuItem(text = { Text("Image / logo") }, onClick = { addMenu = false; pickImage("") })
                    DropdownMenuItem(text = { Text("Texte") }, onClick = { addMenu = false; store.addText("Texte") })
                }
            }
        }
    }
    val layers = @Composable {
        studio.current.sources.forEach { s ->
            LayerRow(
                source = s,
                onToggleVisible = { store.toggleVisible(s.id) },
                onToggleLock = { store.toggleLock(s.id) },
                onUp = { store.moveLayer(s.id, -1) },
                onDown = { store.moveLayer(s.id, 1) },
                onEdit = {
                    if (s.type == SourceType.TEXT) editingText = s.id
                    else if (s.type == SourceType.IMAGE) pickImage(s.id)
                },
                onRename = { renaming = s.id },
                onRemove = { store.removeSource(s.id) }
            )
        }
    }

    if (landscape) {
        Row(Modifier.fillMaxWidth().fillMaxHeight().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(Modifier.weight(1.2f)) {
                header()
                hint()
                PreviewCanvas(controller, store, studio.current, editable = true, modifier = Modifier.fillMaxWidth())
            }
            Column(
                Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                layersHeader()
                layers()
            }
        }
    } else {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            header()
            hint()
            PreviewCanvas(controller, store, studio.current, editable = true, modifier = Modifier.fillMaxWidth())
            layersHeader()
            layers()
        }
    }

    val textSource = studio.current.sources.firstOrNull { it.id == editingText }
    if (textSource != null) {
        TextEditDialog(textSource, onDismiss = { editingText = null }) { text, size, color ->
            store.updateText(textSource.id, text, size, color); editingText = null
        }
    }
    val renamingSource = studio.current.sources.firstOrNull { it.id == renaming }
    if (renamingSource != null) {
        TextInputDialog("Renommer", renamingSource.name, { renaming = null }) {
            store.rename(renamingSource.id, it); renaming = null
        }
    }
}

@Composable
private fun LayerRow(
    source: Source,
    onToggleVisible: () -> Unit,
    onToggleLock: () -> Unit,
    onUp: () -> Unit,
    onDown: () -> Unit,
    onEdit: () -> Unit,
    onRename: () -> Unit,
    onRemove: () -> Unit
) {
    val isCamera = source.type == SourceType.CAMERA
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            if (source.visible) "👁" else "🚫",
            Modifier.clickable(onClick = onToggleVisible).padding(10.dp).alpha(if (source.visible) 1f else 0.5f)
        )
        Column(
            Modifier.weight(1f).clickable(enabled = !isCamera && !source.locked, onClick = onEdit)
        ) {
            Text(source.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(source.type.label, style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (!isCamera) {
            Text(if (source.locked) "🔒" else "🔓", Modifier.clickable(onClick = onToggleLock).padding(8.dp))
            Text("↑", Modifier.clickable(onClick = onUp).padding(8.dp), fontSize = 16.sp)
            Text("↓", Modifier.clickable(onClick = onDown).padding(8.dp), fontSize = 16.sp)
            Text("✎", Modifier.clickable(onClick = onRename).padding(8.dp), fontSize = 16.sp)
            Text("✕", Modifier.clickable(onClick = onRemove).padding(8.dp), fontSize = 16.sp)
        }
    }
}

private val TEXT_COLORS = listOf(
    -1, 0xFFFFEB3B.toInt(), 0xFF00E5FF.toInt(), 0xFFFF5252.toInt(), 0xFF000000.toInt()
)

@Composable
private fun TextEditDialog(
    source: Source,
    onDismiss: () -> Unit,
    onSave: (text: String, size: Int, color: Int) -> Unit
) {
    var text by remember(source.id) { mutableStateOf(source.text) }
    var textSize by remember(source.id) { mutableStateOf(source.textSize.toFloat()) }
    var color by remember(source.id) { mutableStateOf(source.color) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Texte") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = text, onValueChange = { text = it }, label = { Text("Contenu") })
                Text("Taille : ${textSize.toInt()}")
                Slider(value = textSize, onValueChange = { textSize = it }, valueRange = 20f..150f)
                Text("Couleur")
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    TEXT_COLORS.forEach { c ->
                        Box(
                            Modifier.size(32.dp).clip(RoundedCornerShape(50)).background(Color(c))
                                .clickable { color = c }
                        )
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onSave(text, textSize.toInt(), color) }) { Text("OK") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}
