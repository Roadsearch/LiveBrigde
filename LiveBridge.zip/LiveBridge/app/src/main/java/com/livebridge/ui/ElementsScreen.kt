package com.livebridge.ui

import android.content.res.Configuration
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.livebridge.rtmp.StreamController
import com.livebridge.studio.Source
import com.livebridge.studio.SourceType
import com.livebridge.studio.StudioStore

@Composable
fun ElementsScreen(controller: StreamController, store: StudioStore, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val studio by store.state.collectAsState()
    var addMenu by remember { mutableStateOf(false) }
    var editingText by remember { mutableStateOf<String?>(null) }
    var imageTarget by remember { mutableStateOf<String?>(null) }
    var renaming by remember { mutableStateOf<String?>(null) }
    var removing by remember { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        val target = imageTarget
        imageTarget = null
        if (uri != null && target != null) decodeLogo(ctx, uri, 1024)?.let { bmp ->
            if (target.isEmpty()) store.addImage("Logo", bmp) else store.replaceImage(target, bmp)
        }
    }
    fun pickImage(target: String) {
        imageTarget = target
        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    val sourceCount = studio.current.sources.count { it.type != SourceType.CAMERA }
    val layers: @Composable () -> Unit = {
        if (sourceCount == 0) {
            Box(Modifier.fillMaxWidth().padding(Spacing.xl), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Votre scène est prête", style = MaterialTheme.typography.titleSmall)
                    Text("Ajoutez un logo ou un texte pour personnaliser le direct.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        studio.current.sources.forEach { source ->
            LayerRow(
                source,
                onToggleVisible = { store.toggleVisible(source.id) },
                onToggleLock = { store.toggleLock(source.id) },
                onUp = { store.moveLayer(source.id, -1) },
                onDown = { store.moveLayer(source.id, 1) },
                onEdit = { if (source.type == SourceType.TEXT) editingText = source.id else if (source.type == SourceType.IMAGE) pickImage(source.id) },
                onRename = { renaming = source.id },
                onRemove = { removing = source.id }
            )
        }
    }

    val controls: @Composable () -> Unit = {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Calques", style = MaterialTheme.typography.titleMedium)
                Text("$sourceCount élément(s) · ${studio.current.name}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Box {
                OutlinedButton(onClick = { addMenu = true }) {
                    Icon(Icons.Filled.Add, contentDescription = null)
                    Text("Ajouter", Modifier.padding(start = 6.dp))
                }
                DropdownMenu(expanded = addMenu, onDismissRequest = { addMenu = false }) {
                    DropdownMenuItem(leadingIcon = { Icon(Icons.Filled.Image, null) }, text = { Text("Image / logo") }, onClick = { addMenu = false; pickImage("") })
                    DropdownMenuItem(text = { Text("Texte") }, onClick = { addMenu = false; store.addText("Texte") })
                }
            }
        }
    }

    if (landscape) {
        Row(Modifier.fillMaxSize().padding(Spacing.l), horizontalArrangement = Arrangement.spacedBy(Spacing.l)) {
            Column(Modifier.weight(1.25f).fillMaxHeight()) {
                StepHeader(2, 3, "Composer", "Positionnez vos éléments")
                SettingCard("Aperçu tactile", "Glissez avec un doigt · pincez avec deux doigts") {
                    PreviewCanvas(controller, store, studio.current, editable = true, modifier = Modifier.fillMaxWidth())
                }
                Row(Modifier.fillMaxWidth().padding(top = Spacing.s), horizontalArrangement = Arrangement.End) {
                    Button(onClick = onDone) { Text("Continuer vers la diffusion") }
                }
            }
            Column(Modifier.weight(.9f).fillMaxHeight().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(Spacing.s)) {
                controls()
                layers()
            }
        }
    } else {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(Spacing.l), verticalArrangement = Arrangement.spacedBy(Spacing.m)) {
            StepHeader(2, 3, "Composer", "Positionnez vos éléments")
            SettingCard("Aperçu tactile", "Glissez avec un doigt · pincez avec deux doigts") {
                PreviewCanvas(controller, store, studio.current, editable = true, modifier = Modifier.fillMaxWidth())
            }
            controls()
            layers()
            Button(onClick = onDone, modifier = Modifier.fillMaxWidth().padding(top = Spacing.s)) { Text("Continuer vers la diffusion") }
        }
    }

    studio.current.sources.firstOrNull { it.id == editingText }?.let { source ->
        TextEditDialog(source, { editingText = null }) { text, size, color -> store.updateText(source.id, text, size, color); editingText = null }
    }
    studio.current.sources.firstOrNull { it.id == renaming }?.let { source ->
        TextInputDialog("Renommer la source", source.name, { renaming = null }) { store.rename(source.id, it); renaming = null }
    }
    studio.current.sources.firstOrNull { it.id == removing }?.let { source ->
        AlertDialog(
            onDismissRequest = { removing = null },
            title = { Text("Supprimer la source ?") },
            text = { Text("« ${source.name} » sera retirée de la scène. Cette action est irréversible.") },
            confirmButton = { TextButton(onClick = { store.removeSource(source.id); removing = null }) { Text("Supprimer", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { removing = null }) { Text("Annuler") } }
        )
    }
}

@Composable
private fun LayerRow(
    source: Source,
    onToggleVisible: () -> Unit,
    onToggleLock: () -> Unit,
    onUp: () -> Unit,
    onDown: () -> Unit,
    onEdit: () -> Unit,
    onRename: () -> Unit,
    onRemove: () -> Unit
) {
    val camera = source.type == SourceType.CAMERA
    Row(
        Modifier.fillMaxWidth().clip(MaterialTheme.shapes.medium)
            .background(if (source.locked) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 6.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onToggleVisible) { Icon(if (source.visible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff, contentDescription = "Visibilité") }
        Box(Modifier.size(32.dp).background(MaterialTheme.colorScheme.primaryContainer, CircleShape), contentAlignment = Alignment.Center) {
            Text(if (camera) "C" else if (source.type == SourceType.TEXT) "T" else "I", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onPrimaryContainer)
        }
        Column(Modifier.weight(1f).clickable(enabled = !camera, onClick = onEdit).padding(horizontal = 10.dp, vertical = 7.dp)) {
            Text(source.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
            Text(source.type.label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (!camera) {
            IconButton(onClick = onToggleLock) { Icon(if (source.locked) Icons.Filled.Lock else Icons.Filled.LockOpen, contentDescription = "Verrouillage") }
            IconButton(onClick = onUp) { Icon(Icons.Filled.ArrowUpward, contentDescription = "Monter") }
            IconButton(onClick = onDown) { Icon(Icons.Filled.ArrowDownward, contentDescription = "Descendre") }
            IconButton(onClick = onRename) { Icon(Icons.Filled.Edit, contentDescription = "Renommer") }
            IconButton(onClick = onRemove) { Icon(Icons.Filled.DeleteOutline, contentDescription = "Supprimer") }
        }
    }
}

private val TEXT_COLORS = listOf(-1, 0xFFFFEB3B.toInt(), 0xFF00E5FF.toInt(), 0xFFFF5252.toInt(), 0xFF000000.toInt())

@Composable
private fun TextEditDialog(source: Source, onDismiss: () -> Unit, onSave: (String, Int, Int) -> Unit) {
    var text by remember(source.id) { mutableStateOf(source.text) }
    var textSize by remember(source.id) { mutableStateOf(source.textSize.toFloat()) }
    var color by remember(source.id) { mutableStateOf(source.color) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Modifier le texte") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = text, onValueChange = { text = it }, label = { Text("Contenu") })
                Text("Taille · ${textSize.toInt()} px", style = MaterialTheme.typography.labelLarge)
                Slider(value = textSize, onValueChange = { textSize = it }, valueRange = 20f..150f)
                Text("Couleur", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    TEXT_COLORS.forEach { c -> Box(Modifier.size(34.dp).clip(CircleShape).background(Color(c)).clickable { color = c }) }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onSave(text, textSize.toInt(), color) }) { Text("Enregistrer") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}
