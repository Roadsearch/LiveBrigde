package com.livebridge.rtmp

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.SurfaceView
import com.livebridge.LiveService
import com.pedro.common.ConnectChecker
import com.pedro.encoder.input.sources.video.Camera2Source
import com.pedro.encoder.input.gl.render.filters.`object`.ImageObjectFilterRender
import com.pedro.encoder.input.gl.render.filters.`object`.TextObjectFilterRender
import com.pedro.encoder.utils.gl.TranslateTo
import com.pedro.library.generic.GenericStream
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class RtmpUi(
    val streaming: Boolean = false,
    val connecting: Boolean = false,
    val bitrateKbps: Long = 0,
    val quality: Quality = Quality.P720,
    val message: String? = null
)

enum class Quality(val label: String, val w: Int, val h: Int, val bitrate: Int) {
    P480("480p", 854, 480, 1_200_000),
    P720("720p", 1280, 720, 2_500_000),
    P1080("1080p", 1920, 1080, 4_500_000)
}

/**
 * Enveloppe de RootEncoder (GenericStream) : caméra + micro -> RTMP / RTMPS / SRT.
 * Singleton : le flux survit aux changements d'onglet et de configuration.
 * Le protocole est choisi d'après l'URL (rtmp://, rtmps://, srt://, rtsp://...).
 */
class StreamController private constructor(private val app: Context) : ConnectChecker {

    private val main = Handler(Looper.getMainLooper())
    private val _ui = MutableStateFlow(RtmpUi())
    val ui: StateFlow<RtmpUi> = _ui.asStateFlow()

    private val stream = GenericStream(app, this).apply {
        getGlInterface().autoHandleOrientation = true
    }

    private var preparedQuality: Quality? = null
    private var surface: SurfaceView? = null

    // ---- Préparation encodeur ------------------------------------------------------------

    private fun prepare(): Boolean {
        val q = _ui.value.quality
        if (preparedQuality == q) return true
        return try {
            val ok = stream.prepareVideo(q.w, q.h, q.bitrate) &&
                stream.prepareAudio(44100, true, 128_000)
            if (ok) preparedQuality = q
            ok
        } catch (e: IllegalArgumentException) {
            false
        }
    }

    // ---- Aperçu --------------------------------------------------------------------------

    fun attachPreview(view: SurfaceView) {
        surface = view
        if (!prepare()) {
            _ui.update { it.copy(message = "Cet appareil ne supporte pas cette qualité.") }
            return
        }
        if (!stream.isOnPreview) stream.startPreview(view)
    }

    fun onPreviewSize(width: Int, height: Int) {
        stream.getGlInterface().setPreviewResolution(width, height)
    }

    fun detachPreview() {
        if (stream.isOnPreview) stream.stopPreview()
        surface = null
    }

    fun setQuality(q: Quality) {
        if (stream.isStreaming) return
        _ui.update { it.copy(quality = q, message = null) }
        val view = surface
        if (stream.isOnPreview) stream.stopPreview()
        if (prepare() && view != null) stream.startPreview(view)
    }

    fun switchCamera() {
        runCatching { (stream.videoSource as Camera2Source).switchCamera() }
            .onFailure { _ui.update { s -> s.copy(message = "Impossible de changer de caméra.") } }
    }

    // ---- Overlays (dessinés dans le flux) ------------------------------------------------

    /** Remplace tous les overlays : logo (coin haut-droit) et titre (bas). */
    fun setOverlays(title: String, logo: Bitmap?) {
        val gl = stream.getGlInterface()
        gl.clearFilters()

        if (logo != null) {
            val q = _ui.value.quality
            val f = ImageObjectFilterRender()
            gl.addFilter(f)               // ajouter AVANT de configurer
            f.setImage(logo)
            val sx = 15f                  // largeur = 15 % de l'image
            val sy = sx * (logo.height.toFloat() / logo.width) * (q.w.toFloat() / q.h)
            f.setScale(sx, sy)
            f.setPosition(TranslateTo.TOP_RIGHT)
        }
        if (title.isNotBlank()) {
            val f = TextObjectFilterRender()
            gl.addFilter(f)
            f.setText(title.trim(), 40f, Color.WHITE)
            f.setPosition(TranslateTo.BOTTOM)
        }
    }

    // ---- Diffusion -----------------------------------------------------------------------

    fun start(url: String) {
        if (stream.isStreaming) return
        if (!prepare()) {
            _ui.update { it.copy(message = "Encodeur indisponible.") }
            return
        }
        _ui.update { it.copy(connecting = true, message = null) }
        try {
            LiveService.start(app, "Live RTMP")
            stream.startStream(url.trim())
        } catch (e: Exception) {
            _ui.update { it.copy(connecting = false, message = "Erreur : ${e.message}") }
            LiveService.stop(app)
        }
    }

    fun stop() {
        if (stream.isStreaming) stream.stopStream()
        _ui.update { it.copy(streaming = false, connecting = false, bitrateKbps = 0) }
        LiveService.stop(app)
    }

    // ---- ConnectChecker (appelé depuis des threads d'arrière-plan) ---------------------

    override fun onConnectionStarted(url: String) {}

    override fun onConnectionSuccess() {
        _ui.update { it.copy(streaming = true, connecting = false, message = null) }
    }

    override fun onConnectionFailed(reason: String) {
        main.post {
            stop()
            _ui.update { it.copy(message = "Connexion échouée : $reason") }
        }
    }

    override fun onNewBitrate(bitrate: Long) {
        _ui.update { it.copy(bitrateKbps = bitrate / 1000) }
    }

    override fun onDisconnect() {
        _ui.update { it.copy(streaming = false, connecting = false, bitrateKbps = 0) }
    }

    override fun onAuthError() {
        main.post {
            stop()
            _ui.update { it.copy(message = "Authentification refusée par le serveur.") }
        }
    }

    override fun onAuthSuccess() {}

    companion object {
        @Volatile private var instance: StreamController? = null

        fun get(context: Context): StreamController =
            instance ?: synchronized(this) {
                instance ?: StreamController(context.applicationContext).also { instance = it }
            }
    }
}
