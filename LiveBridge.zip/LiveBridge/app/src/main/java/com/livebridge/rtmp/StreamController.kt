package com.livebridge.rtmp

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.SurfaceView
import com.livebridge.LiveService
import com.pedro.common.ConnectChecker
import com.pedro.encoder.input.gl.render.filters.`object`.ImageObjectFilterRender
import com.pedro.encoder.input.gl.render.filters.`object`.TextObjectFilterRender
import com.pedro.encoder.input.sources.video.Camera2Source
import com.pedro.encoder.utils.gl.TranslateTo
import com.pedro.library.generic.GenericStream
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.time.LocalTime

enum class Quality(val label: String, val w: Int, val h: Int, val bitrate: Int) {
    P480("480p", 854, 480, 1_200_000),
    P720("720p", 1280, 720, 2_500_000),
    P1080("1080p", 1920, 1080, 4_500_000)
}

/** Scènes façon OBS, commutables en plein live. */
enum class SceneKind(val label: String) {
    CAMERA("Caméra"),
    INFO("Logo + titre"),
    BRB("Pause")
}

data class RtmpUi(
    val streaming: Boolean = false,
    val connecting: Boolean = false,
    val bitrateKbps: Long = 0,
    val quality: Quality = Quality.P720,
    val scene: SceneKind = SceneKind.CAMERA,
    val message: String? = null
)

/**
 * Enveloppe de RootEncoder (GenericStream) : caméra + micro -> RTMP / RTMPS / SRT.
 * Singleton : le flux survit aux changements d'onglet et de configuration.
 * Le protocole est choisi d'après l'URL (rtmp://, rtmps://, srt://, rtsp://...).
 */
class StreamController private constructor(private val app: Context) : ConnectChecker {

    private val main = Handler(Looper.getMainLooper())

    private val _ui = MutableStateFlow(RtmpUi())
    val ui: StateFlow<RtmpUi> = _ui.asStateFlow()

    private val _logs = MutableStateFlow<List<String>>(emptyList())
    val logs: StateFlow<List<String>> = _logs.asStateFlow()

    private val stream = GenericStream(app, this).apply {
        getGlInterface().autoHandleOrientation = true
    }

    private var preparedQuality: Quality? = null
    private var surface: SurfaceView? = null

    // Reconnexion automatique
    private var wantLive = false
    private var retries = 0
    private var lastUrl = ""
    private var retryTask: Runnable? = null

    // ---- Journal (sans jamais écrire la clé de stream) -----------------------------------

    fun log(message: String) {
        val line = "${LocalTime.now().withNano(0)}  $message"
        _logs.update { (it + line).takeLast(80) }
    }

    fun clearLogs() {
        _logs.value = emptyList()
    }

    private fun describe(url: String): String = runCatching {
        val u = Uri.parse(url)
        "${u.scheme}://${u.host}" + (if (u.port > 0) ":${u.port}" else "")
    }.getOrDefault("(URL invalide)")

    // ---- Préparation encodeur ------------------------------------------------------------

    private fun prepare(): Boolean {
        val q = _ui.value.quality
        if (preparedQuality == q) return true
        return try {
            val ok = stream.prepareVideo(q.w, q.h, q.bitrate) &&
                stream.prepareAudio(44100, true, 128_000)
            if (ok) preparedQuality = q
            log(if (ok) "Encodeur prêt (${q.label})" else "Encodeur refusé par l'appareil (${q.label})")
            ok
        } catch (e: IllegalArgumentException) {
            log("Encodeur : ${e.message}")
            false
        }
    }

    // ---- Aperçu --------------------------------------------------------------------------

    fun attachPreview(view: SurfaceView) {
        surface = view
        if (!prepare()) {
            _ui.update { it.copy(message = "Cet appareil ne supporte pas cette qualité.") }
            return
        }
        if (!stream.isOnPreview) stream.startPreview(view)
    }

    fun onPreviewSize(width: Int, height: Int) {
        stream.getGlInterface().setPreviewResolution(width, height)
    }

    fun detachPreview() {
        if (stream.isOnPreview) stream.stopPreview()
        surface = null
    }

    fun setQuality(q: Quality) {
        if (stream.isStreaming || wantLive) return
        _ui.update { it.copy(quality = q, message = null) }
        val view = surface
        if (stream.isOnPreview) stream.stopPreview()
        if (prepare() && view != null) stream.startPreview(view)
    }

    fun switchCamera() {
        runCatching { (stream.videoSource as Camera2Source).switchCamera() }
            .onFailure { _ui.update { s -> s.copy(message = "Impossible de changer de caméra.") } }
    }

    // ---- Scènes (dessinées dans le flux) -------------------------------------------------

    fun applyScene(kind: SceneKind, title: String, logo: Bitmap?, brbText: String) {
        val gl = stream.getGlInterface()
        val q = _ui.value.quality
        gl.clearFilters()

        when (kind) {
            SceneKind.CAMERA -> Unit

            SceneKind.INFO -> {
                if (logo != null) {
                    val f = ImageObjectFilterRender()
                    gl.addFilter(f)               // ajouter AVANT de configurer
                    f.setImage(logo)
                    val sx = 15f                  // largeur = 15 % de l'image
                    val sy = sx * (logo.height.toFloat() / logo.width) * (q.w.toFloat() / q.h)
                    f.setScale(sx, sy)
                    f.setPosition(TranslateTo.TOP_RIGHT)
                }
                if (title.isNotBlank()) {
                    val f = TextObjectFilterRender()
                    gl.addFilter(f)
                    f.setText(title.trim(), 40f, Color.WHITE)
                    f.setPosition(TranslateTo.BOTTOM)
                }
            }

            SceneKind.BRB -> {
                val f = ImageObjectFilterRender()
                gl.addFilter(f)
                f.setImage(brbBitmap(brbText.ifBlank { "Je reviens tout de suite" }, q))
                f.setScale(100f, 100f)            // plein écran
                f.setPosition(TranslateTo.CENTER)
            }
        }
        _ui.update { it.copy(scene = kind) }
        log("Scène : ${kind.label}")
    }

    private fun brbBitmap(text: String, q: Quality): Bitmap {
        val bmp = Bitmap.createBitmap(q.w, q.h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(0xFF111111.toInt())
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textAlign = Paint.Align.CENTER
            textSize = q.h / 10f
        }
        canvas.drawText(text, q.w / 2f, q.h / 2f + paint.textSize / 3f, paint)
        return bmp
    }

    // ---- Diffusion -----------------------------------------------------------------------

    fun start(url: String) {
        if (stream.isStreaming || wantLive) return
        if (!prepare()) {
            _ui.update { it.copy(message = "Encodeur indisponible.") }
            return
        }
        lastUrl = url.trim()
        retries = 0
        wantLive = true
        _ui.update { it.copy(connecting = true, message = null) }
        log("Démarrage vers ${describe(lastUrl)}")
        launchStream()
    }

    private fun launchStream() {
        try {
            LiveService.start(app, "Live RTMP")
            stream.startStream(lastUrl)
        } catch (e: Exception) {
            log("Erreur au démarrage : ${e.message}")
            stop()
            _ui.update { it.copy(message = "Erreur : ${e.message}") }
        }
    }

    fun stop() {
        wantLive = false
        retryTask?.let { main.removeCallbacks(it) }
        retryTask = null
        if (stream.isStreaming) stream.stopStream()
        _ui.update { it.copy(streaming = false, connecting = false, bitrateKbps = 0) }
        LiveService.stop(app)
        log("Live arrêté")
    }

    // ---- ConnectChecker (appelé depuis des threads d'arrière-plan) ---------------------

    override fun onConnectionStarted(url: String) {
        log("Connexion à ${describe(url)}…")
    }

    override fun onConnectionSuccess() {
        retries = 0
        log("Connecté : le serveur accepte le flux")
        _ui.update { it.copy(streaming = true, connecting = false, message = null) }
    }

    override fun onConnectionFailed(reason: String) {
        log("Échec de connexion : $reason")
        main.post {
            if (wantLive && retries < MAX_RETRIES) {
                retries++
                log("Nouvelle tentative $retries/$MAX_RETRIES dans 3 s…")
                if (stream.isStreaming) stream.stopStream()
                _ui.update { it.copy(streaming = false, connecting = true) }
                val task = Runnable { if (wantLive) launchStream() }
                retryTask = task
                main.postDelayed(task, 3000)
            } else {
                stop()
                _ui.update { it.copy(message = "Connexion échouée : $reason") }
            }
        }
    }

    override fun onNewBitrate(bitrate: Long) {
        _ui.update { it.copy(bitrateKbps = bitrate / 1000) }
    }

    override fun onDisconnect() {
        log("Déconnecté du serveur")
        _ui.update { it.copy(streaming = false, bitrateKbps = 0) }
    }

    override fun onAuthError() {
        log("Authentification refusée (clé ou identifiants invalides)")
        main.post {
            stop()
            _ui.update { it.copy(message = "Authentification refusée par le serveur : vérifie la clé de stream.") }
        }
    }

    override fun onAuthSuccess() {
        log("Authentification acceptée")
    }

    companion object {
        private const val MAX_RETRIES = 3
        @Volatile private var instance: StreamController? = null

        fun get(context: Context): StreamController =
            instance ?: synchronized(this) {
                instance ?: StreamController(context.applicationContext).also { instance = it }
            }
    }
}
