package com.livebridge.rtmp

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.view.SurfaceView
import com.livebridge.LiveService
import com.livebridge.studio.Anchor
import com.livebridge.studio.Scene
import com.livebridge.studio.Source
import com.livebridge.studio.SourceType
import com.pedro.common.ConnectChecker
import com.pedro.encoder.input.gl.render.filters.`object`.ImageObjectFilterRender
import com.pedro.encoder.input.gl.render.filters.`object`.TextObjectFilterRender
import com.pedro.encoder.input.sources.video.Camera2Source
import com.pedro.encoder.utils.gl.TranslateTo
import com.pedro.library.generic.GenericStream
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.io.File
import java.time.LocalTime

enum class Quality(val label: String, val w: Int, val h: Int, val bitrate: Int) {
    P480("480p", 854, 480, 1_200_000),
    P720("720p", 1280, 720, 2_500_000),
    P1080("1080p", 1920, 1080, 4_500_000)
}

data class RtmpUi(
    val streaming: Boolean = false,
    val connecting: Boolean = false,
    val liveSince: Long = 0,
    val bitrateKbps: Long = 0,
    val fps: Int = 30,
    val quality: Quality = Quality.P720,
    val sceneName: String = "",
    val recording: Boolean = false,
    val lastRecordPath: String? = null,
    val micMuted: Boolean = false,
    val message: String? = null
)

/**
 * Enveloppe de RootEncoder (GenericStream) : caméra + micro -> RTMP / RTMPS / SRT (+ enregistrement local).
 * Singleton : le flux survit aux changements d'onglet et de configuration.
 */
class StreamController private constructor(private val app: Context) : ConnectChecker {

    private val main = Handler(Looper.getMainLooper())

    private val _ui = MutableStateFlow(RtmpUi())
    val ui: StateFlow<RtmpUi> = _ui.asStateFlow()

    private val _logs = MutableStateFlow<List<String>>(emptyList())
    val logs: StateFlow<List<String>> = _logs.asStateFlow()

    /** Appelé après chaque démarrage d'aperçu : le studio y ré-applique la scène active. */
    var onPreviewStarted: (() -> Unit)? = null

    private val stream = GenericStream(app, this).apply {
        getGlInterface().autoHandleOrientation = true
    }

    private var preparedQuality: Quality? = null
    private var surface: SurfaceView? = null

    // Reconnexion automatique
    private var wantLive = false
    private var retries = 0
    private var lastUrl = ""
    private var retryTask: Runnable? = null

    // ---- Journal (sans jamais écrire la clé de stream) -----------------------------------

    fun log(message: String) {
        val line = "${LocalTime.now().withNano(0)}  $message"
        _logs.update { (it + line).takeLast(80) }
    }

    fun clearLogs() {
        _logs.value = emptyList()
    }

    private fun describe(url: String): String = runCatching {
        val u = Uri.parse(url)
        "${u.scheme}://${u.host}" + (if (u.port > 0) ":${u.port}" else "")
    }.getOrDefault("(URL invalide)")

    // ---- Préparation encodeur ------------------------------------------------------------

    private fun prepare(): Boolean {
        val q = _ui.value.quality
        if (preparedQuality == q) return true
        return try {
            val ok = stream.prepareVideo(q.w, q.h, q.bitrate) &&
                stream.prepareAudio(44100, true, 128_000)
            if (ok) preparedQuality = q
            log(if (ok) "Encodeur prêt (${q.label})" else "Encodeur refusé par l'appareil (${q.label})")
            ok
        } catch (e: IllegalArgumentException) {
            log("Encodeur : ${e.message}")
            false
        }
    }

    // ---- Aperçu --------------------------------------------------------------------------

    fun attachPreview(view: SurfaceView) {
        surface = view
        if (!prepare()) {
            _ui.update { it.copy(message = "Cet appareil ne supporte pas cette qualité.") }
            return
        }
        if (!stream.isOnPreview) {
            stream.startPreview(view)
            onPreviewStarted?.invoke()
        }
    }

    fun onPreviewSize(width: Int, height: Int) {
        stream.getGlInterface().setPreviewResolution(width, height)
    }

    fun detachPreview() {
        if (stream.isOnPreview) stream.stopPreview()
        surface = null
    }

    fun setQuality(q: Quality) {
        if (stream.isStreaming || wantLive || _ui.value.recording) return
        _ui.update { it.copy(quality = q, message = null) }
        val view = surface
        if (stream.isOnPreview) stream.stopPreview()
        if (prepare() && view != null) {
            stream.startPreview(view)
            onPreviewStarted?.invoke()
        }
    }

    fun switchCamera() {
        runCatching { (stream.videoSource as Camera2Source).switchCamera() }
            .onFailure { _ui.update { s -> s.copy(message = "Impossible de changer de caméra.") } }
    }

    // ---- Micro ---------------------------------------------------------------------------

    /**
     * Coupe / réactive le micro. Appel par réflexion : si cette version de RootEncoder n'expose pas
     * la méthode, l'app continue de fonctionner et l'indique dans le journal.
     */
    fun setMicMuted(muted: Boolean) {
        val source = runCatching { stream.javaClass.getMethod("getAudioSource").invoke(stream) }.getOrNull()
        val names = if (muted) listOf("mute") else listOf("unMute", "unmute")
        val ok = source != null && names.any { name ->
            runCatching { source.javaClass.getMethod(name).invoke(source) }.isSuccess
        }
        if (ok) {
            _ui.update { it.copy(micMuted = muted) }
            log(if (muted) "Micro coupé" else "Micro actif")
        } else {
            log("Couper le micro n'est pas supporté par cette version de RootEncoder")
            _ui.update { it.copy(message = "Impossible de couper le micro sur cette version.") }
        }
    }

    // ---- Rendu de la scène active (dessiné dans le flux) ---------------------------------

    fun renderScene(scene: Scene, imageFor: (Source) -> Bitmap?) {
        _ui.update { it.copy(sceneName = scene.name) }
        if (!stream.isOnPreview && !stream.isStreaming) return   // rendu différé (onPreviewStarted)

        val gl = stream.getGlInterface()
        val q = _ui.value.quality
        gl.clearFilters()

        fun anchor(a: Anchor): TranslateTo =
            runCatching { TranslateTo.valueOf(a.name) }.getOrDefault(TranslateTo.CENTER)

        // Caméra masquée : on la recouvre d'un fond noir plein écran.
        val cam = scene.sources.firstOrNull { it.type == SourceType.CAMERA }
        if (cam == null || !cam.visible) {
            val black = Bitmap.createBitmap(2, 2, Bitmap.Config.ARGB_8888).apply { eraseColor(0xFF000000.toInt()) }
            val f = ImageObjectFilterRender()
            gl.addFilter(f)
            f.setImage(black)
            f.setScale(100f, 100f)
            f.setPosition(TranslateTo.CENTER)
        }

        // asReversed : l'arrière-plan d'abord, le premier plan en dernier.
        for (s in scene.sources.asReversed()) {
            if (!s.visible) continue
            when (s.type) {
                SourceType.CAMERA -> Unit

                SourceType.IMAGE -> {
                    val bmp = imageFor(s) ?: continue
                    val f = ImageObjectFilterRender()
                    gl.addFilter(f)               // ajouter AVANT de configurer
                    f.setImage(bmp)
                    val sx = s.size.toFloat()
                    val sy = sx * (bmp.height.toFloat() / bmp.width) * (q.w.toFloat() / q.h)
                    f.setScale(sx, sy)
                    f.setPosition(anchor(s.anchor))
                }

                SourceType.TEXT -> {
                    if (s.text.isBlank()) continue
                    val f = TextObjectFilterRender()
                    gl.addFilter(f)
                    f.setText(s.text.trim(), s.textSize.toFloat(), s.color)
                    f.setPosition(anchor(s.anchor))
                }
            }
        }
        log("Scène : ${scene.name}")
    }

    // ---- Enregistrement local ------------------------------------------------------------

    fun toggleRecord() {
        if (_ui.value.recording) {
            runCatching { stream.stopRecord() }
            _ui.update { it.copy(recording = false) }
            log("Enregistrement terminé : ${_ui.value.lastRecordPath}")
            return
        }
        if (!prepare()) {
            _ui.update { it.copy(message = "Encodeur indisponible.") }
            return
        }
        val dir = app.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: app.filesDir
        val file = File(dir, "LiveBridge_${System.currentTimeMillis()}.mp4")
        try {
            stream.startRecord(file.absolutePath) { status -> log("Enregistrement : $status") }
            _ui.update { it.copy(recording = true, lastRecordPath = file.absolutePath, message = null) }
            log("Enregistrement démarré")
        } catch (e: Exception) {
            log("Enregistrement impossible : ${e.message}")
            _ui.update { it.copy(message = "Enregistrement impossible : ${e.message}") }
        }
    }

    // ---- Diffusion -----------------------------------------------------------------------

    fun start(url: String) {
        if (stream.isStreaming || wantLive) return
        if (!prepare()) {
            _ui.update { it.copy(message = "Encodeur indisponible.") }
            return
        }
        lastUrl = url.trim()
        retries = 0
        wantLive = true
        _ui.update { it.copy(connecting = true, message = null) }
        log("Démarrage vers ${describe(lastUrl)}")
        launchStream()
    }

    private fun launchStream() {
        try {
            LiveService.start(app, "Live RTMP")
            stream.startStream(lastUrl)
        } catch (e: Exception) {
            log("Erreur au démarrage : ${e.message}")
            stop()
            _ui.update { it.copy(message = "Erreur : ${e.message}") }
        }
    }

    fun stop() {
        wantLive = false
        retryTask?.let { main.removeCallbacks(it) }
        retryTask = null
        if (stream.isStreaming) stream.stopStream()
        _ui.update { it.copy(streaming = false, connecting = false, bitrateKbps = 0, liveSince = 0) }
        LiveService.stop(app)
        log("Live arrêté")
    }

    // ---- ConnectChecker (appelé depuis des threads d'arrière-plan) ---------------------

    override fun onConnectionStarted(url: String) {
        log("Connexion à ${describe(url)}…")
    }

    override fun onConnectionSuccess() {
        retries = 0
        log("Connecté : le serveur accepte le flux")
        _ui.update {
            it.copy(streaming = true, connecting = false, liveSince = System.currentTimeMillis(), message = null)
        }
    }

    override fun onConnectionFailed(reason: String) {
        log("Échec de connexion : $reason")
        main.post {
            if (wantLive && retries < MAX_RETRIES) {
                retries++
                log("Nouvelle tentative $retries/$MAX_RETRIES dans 3 s…")
                if (stream.isStreaming) stream.stopStream()
                _ui.update { it.copy(streaming = false, connecting = true) }
                val task = Runnable { if (wantLive) launchStream() }
                retryTask = task
                main.postDelayed(task, 3000)
            } else {
                stop()
                _ui.update { it.copy(message = "Connexion échouée : $reason") }
            }
        }
    }

    override fun onNewBitrate(bitrate: Long) {
        _ui.update { it.copy(bitrateKbps = bitrate / 1000) }
    }

    override fun onDisconnect() {
        log("Déconnecté du serveur")
        _ui.update { it.copy(streaming = false, bitrateKbps = 0) }
    }

    override fun onAuthError() {
        log("Authentification refusée (clé ou identifiants invalides)")
        main.post {
            stop()
            _ui.update { it.copy(message = "Authentification refusée par le serveur : vérifie la clé de stream.") }
        }
    }

    override fun onAuthSuccess() {
        log("Authentification acceptée")
    }

    companion object {
        private const val MAX_RETRIES = 3
        @Volatile private var instance: StreamController? = null

        fun get(context: Context): StreamController =
            instance ?: synchronized(this) {
                instance ?: StreamController(context.applicationContext).also { instance = it }
            }
    }
}
